export default()=>({
contact:'deepak.verma@srmtechsol.com',
category:'121',
subcategory:'601',
impact:'4-Low',
urgency:'3-Low',
udhd_url : "https://udhddev.service-now.com/api/now/table/sn_customerservice_case",
udhd_username : 'engineering.integration',
udhd_pwd:'engineering.integration',
'101_short_description':'BIN button is not working on brand website because of incorrect SmartProductId.',
'101_description':'There is a problem with one of the products Buy It Now (BIN) button on "PDP_URL". BIN button is not working because SmartProductId is incorrect. Please check that PIM sheet has correct SmartproductId for the product which should look something like this "HASH_KEY". If not sure, log a Kana ticket for support here https://udhd.service-now.com/csm?id=csm_get_help&sys_id=990686831b3cc0d076bc6428bd4bcba2',
'105_short_description':'BIN button is not working on brand website because of missing SmartProductId.',
'105_description':'There is a problem with one of the products Buy It Now (BIN) button on "PDP_URL". BIN button is not working because SmartProductId is missing. Please check that PIM sheet has a SmartproductId for the product which looks something like this "HASH_KEY", and it is being correctly passed to Cartwire widget in the code. If the ID is missing, log a Kana ticket to onboard the product on Cartwire here https://udhd.service-now.com/csm?id=sc_cat_item&sys_id=037002af1b851090cd9b1028bd4bcbe1',
'102_short_description':'BIN button is not working on brand website because of invalid widget Theme.',
'102_description':'There is a problem with Buy It Now (BIN) button on PDP_URL. BIN button is not working because incorrect value for theme type is being passed to Cartwire widget. Ask the agency to pass correct parameter. In most cases it is "retailPopup" but if not working or not sure what parameter to pass, reach out to Cartwire team.',
'103_short_description':'BIN button is not working on brand website because of incorrect language code.',
'103_description':"There is a problem with Buy It Now (BIN) button on PDP_URL. BIN button is not working because incorrect language id is being passed to the widget. Currently it is passing language code as 'en' whereas widget is configured to accept 'fr'",
'API_KEY':'daed6140-c7ff-4366-9eb8-c511afd0c9ee'
})