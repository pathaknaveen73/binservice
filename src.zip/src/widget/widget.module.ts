import { Module } from '@nestjs/common';
import { WidgetService } from './widget.service';
import { WidgetController } from './widget.controller';
import { RetailerInfoModule } from '../retailer_info/retailer_info.module';
import { WidgetSchema } from './schemas/widget.schema';
import { widgetProviders } from './widget.providers';
import { DatabaseModule } from '../database/database.module';
import { AcceptLanguageResolver, I18nModule, QueryResolver } from 'nestjs-i18n';
import { join } from 'path';

@Module({
  imports: [DatabaseModule,
    RetailerInfoModule,
    I18nModule.forRoot({
    fallbackLanguage: 'en',
    loaderOptions: {
      path: join(__dirname, '..', '/i18n/'),
      watch: true, 
    },
    resolvers: [
      { use: QueryResolver, options: ['lang'] }, 
      AcceptLanguageResolver,
      ],
  })],
  controllers: [WidgetController],
  providers: [WidgetService, ...widgetProviders],
  exports: [WidgetService],
})
export class WidgetModule {}
