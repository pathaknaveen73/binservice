import { Model } from 'mongoose';
import { Injectable, Inject,NotFoundException} from '@nestjs/common';
import { Widget } from './interfaces/widget.interface';
import { RetailerInfoService } from '../retailer_info/retailer_info.service';
import { I18nService } from 'nestjs-i18n';
import static_data from 'src/constants/static_data';

@Injectable()
export class WidgetService {
  constructor(
      @Inject('WIDGET_MODEL')
      private widgetModel: Model<Widget>,
      @Inject(RetailerInfoService)
      private readonly RetailerInfoService: RetailerInfoService,
      private readonly datamodel: I18nService,
  ){}
  
 /*
  * @created  : April 10, 2023
  * @modified : April 11, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The purpose of this function is to find and retrieve a widget based on a provided hash key and language code, it also handles error cases and retrieves the widget data when valid, applying localization and data manipulation
  * @params   : hash_key, lang_code 
  * @return   : Response
  */

  async findOne(hash_key: any, lang_code: any) 
  {
    let binKStatus: any, binEANStatus: any;
    let binLangStatus:any, binIsActive: any, binHashKey = '', binProdEAN: '', binLangCode: any, isActive: any, binLocaleStatus:any,binLocale:any;
    let LangCodes = lang_code, isolangCode: any;
    let langCode = '';
    let errorValue = '';
    let errorMsg: any, errorDesc: any, hashKey: any, countryName: any, brandName: any, productEAN = '', binCountry = '', binBrandName = '', langData = '';
    let finalErrorMsg: any, firstDesc: any, errorWidget: any, langComma: any, finalLang: any;
    let locData: any, brandData:any;
    
    //-- Localization --// 
    locData = await this.RetailerInfoService.locale(langCode,false);

    //-- Error Code Message --//
    if ((hash_key == '') && ((LangCodes.includes('-') || (LangCodes.length == 5 )))) 
    {
      errorValue = static_data.MISSING_EAN_CODE;
      errorMsg = locData.MISSING_EAN_TXT;
      errorDesc = locData.MISSING_EAN_DESC;
      hashKey = '';
      countryName = '';
      brandName = '';
      productEAN = '';
      finalErrorMsg = true;
    }
    else if(hash_key == '')
    {
      errorValue = static_data.MISSING_SMARTID_CODE;
      errorMsg = locData.MISSING_SMART_ID_TXT;
      errorDesc = locData.MISSING_SMART_ID_DESC;
      hashKey = '';
      countryName = '';
      brandName = '';
      productEAN = '';
      finalErrorMsg = true;
    }
    else 
    {
      errorWidget = await this.widgetModel.aggregate([
        {
          $match: {
            $or: [
              { product_ean: hash_key },
              { hash_key: hash_key }
            ]
          }
        },
        {
          $project: {
            hash_key: 1,
            language_code: 1,
            is_active: 1,
            brand_name: 1,
            country: 1,
            product_ean: 1,
            locale: 1
          }
        }
      ]).exec();

      let binLang = [], binLoc = [];
      if (errorWidget.length > 1) 
      {
        let hKey:any,pEan:any,lCode:any,cOU:any,bName:any,isAct:any,finalCode:any,lOC:any;
        let firstLang = '', secondLang = '';
        let LangData = 0, LocData = 0;
        for (const errorDetails of errorWidget)
        {
          hKey = errorDetails.hash_key,
          pEan = errorDetails.product_ean,
          lCode = errorDetails.language_code,
          cOU = errorDetails.country,
          bName = errorDetails.brand_name,
          isAct = errorDetails.is_active,
          lOC = errorDetails.locale
          //-- Language Comma --//
          if(lCode.includes(",")){
            finalCode = lCode.split(",");
            firstLang = finalCode[0]; 
            secondLang = finalCode[1];   
          }else{
            firstLang = lCode;
            binLang.push(firstLang);
          }

          //-- Locale Array --// 
          binLoc.push(lOC);
          
          //-- Valid Language Code Check --//
          if((hKey == hash_key) && ((LangCodes == firstLang) || (LangCodes == secondLang)))
          {
            binHashKey = hKey,
            binProdEAN = pEan,
            binLangCode = lCode,
            binCountry = cOU,
            binBrandName = bName,
            binIsActive = isAct,
            binLocale = lOC,
            LangData = 1;
            binLangStatus = false;
          }
          //-- Invalid Language Code Check --//
          else if((hKey == hash_key) && ((LangCodes != firstLang) || (LangCodes != secondLang)) && (LangData == 0))
          {
            binHashKey = hKey,
            binProdEAN = pEan,
            binLangCode = lCode,
            binCountry = cOU,
            binBrandName = bName,
            binIsActive = isAct,
            binLocale = lOC,
            binLangStatus = true;
          }
          
          //-- Valid Locle Code Check --//
          if((pEan == hash_key) && ((LangCodes == lOC)))
          {
            binHashKey = hKey,
            binProdEAN = pEan,
            binLangCode = lCode,
            binCountry = cOU,
            binBrandName = bName,
            binIsActive = isAct,
            binLocale = binLoc,
            LocData = 1;
            binLocaleStatus = false;
          }
          //-- Invalid Locle Code Check --//
          else if((pEan == hash_key) && ((LangCodes != lOC)) && (LocData == 0))
          {
            binHashKey = hKey,
            binProdEAN = pEan,
            binLangCode = lCode,
            binCountry = cOU,
            binBrandName = bName,
            binIsActive = isAct,
            binLocale = binLoc,
            binLocaleStatus = true;
          }
        }  
      }
      else
      {
        if (errorWidget != '') 
        {
          binIsActive = errorWidget[0].is_active,
          binHashKey = errorWidget[0].hash_key,
          binProdEAN = errorWidget[0].product_ean,
          binLangCode = errorWidget[0].language_code,
          binCountry = errorWidget[0].country,
          binBrandName = errorWidget[0].brand_name,
          binLocale = errorWidget[0].locale
        }
      }

      if(binBrandName!='' && typeof binBrandName != "undefined")
      {
        brandData = await this.RetailerInfoService.brandInfo(binBrandName);
        if(brandData && brandData.enable_child_locale)
        {
          locData = await this.RetailerInfoService.locale(langCode,brandData);
        }
      }

      if (hash_key)
      {
        hashKey = binHashKey;
        countryName = binCountry;
        brandName = binBrandName;
        productEAN = binProdEAN;

        if (binHashKey == '') {
          if ((/^(?=.*\d)(?=.*[a-zA-Z]).{8,}$/.test(hash_key)) && (hash_key.length < 32) || (hash_key.length >= 32)) {
            binKStatus = true;
          } else if ((/^(?=.*[a-zA-Z]).{8,}$/.test(hash_key))) {
            binKStatus = true;
          } 
        }

        if ((binProdEAN == '') || (typeof binProdEAN == 'undefined')) {
          if (Number.isInteger(parseInt(hash_key))) {
            binEANStatus = true;
          }
        }

        if ((binHashKey || binProdEAN) && (binIsActive == '')) {
          isActive = true;
        }
      }
      
      //-- Check Invalid Hash Key --//
      if (binKStatus)
      {
        errorValue = static_data.INVALID_PRODUCT_CODE;
        errorMsg = locData.INVALID_PRODUCT_CODE_TXT;
        errorDesc = locData.INVALID_PRODUCT_CODE_DESC;
        finalErrorMsg = true;
      }
      
      //-- Check Invalid EAN --//
      if (binEANStatus)
      {
        errorValue = static_data.INVALID_PRODUCT_EAN;
        errorMsg = locData.INVALID_EAN_CODE_TXT;
        errorDesc = locData.INVALID_EAN_CODE_DESC;
        finalErrorMsg = true;
      }

      //-- Check Invalid Lanaguage --//
      if (binLangStatus) 
      {
        errorValue = static_data.INVALID_LANGUAGE_CODE;
        if (LangCodes == "") 
        {
          errorMsg = locData.MISSING_LANGUAGE_STATUS_TXT;
          errorDesc = locData.MISSING_LANGUAGE_STATUS_DESC;
          langComma = binLangCode.includes(",");
          if (langComma) {
            langData = binLangCode.split(",");
            langCode = `${langData[0]}`;
            isolangCode = `${langData[1]}`;
            finalLang = `${langData[0]} or ${langData[1]}`;
          } else {
            finalLang = binLangCode;
          }
          
          errorDesc = errorDesc.replace('[fLang]', finalLang);
          finalErrorMsg = true;
        }
        else if (LangCodes.length != '2') 
        {
          errorMsg = locData.INVALID_LANGUAGE_CODE_TXT;
          errorDesc = locData.INVALID_LANGUAGE_LENGTH_DESC;
          finalErrorMsg = true;
        }
        else if (!LangCodes.match(/^[a-zA-Z]+$/)) 
        {
          errorMsg = locData.INVALID_LANGUAGE_CODE_TXT;
          errorDesc = locData.INVALID_LANGUAGE_ALPHA_DESC;
          finalErrorMsg = true;
        }
        else 
        {
          errorMsg = locData.INVALID_LANGUAGE_CODE_TXT;
          errorDesc = locData.INVALID_LANGUAGE_CODE_DESC;
          firstDesc = errorDesc.replace('[rlang]', LangCodes);
          langComma = binLangCode.includes(",");
          if (langComma) {
            langData = binLangCode.split(",");
            langCode = `${langData[0]}`;
            isolangCode = `${langData[1]}`;
            finalLang = `${langData[0]} or ${langData[1]}`;
          } else {
            finalLang = binLangCode;
          }

          if((typeof langCode != "undefined") && ((typeof isolangCode != "undefined")))
          {
            if ((langCode != LangCodes) && (isolangCode != LangCodes))
            {
              errorDesc = firstDesc.replace('[clang]', finalLang);
              finalErrorMsg = true;
            }
          }
          else
          {
            if(binLang.length > 1){
              finalLang = `${binLang[0]} or ${binLang[1]}`;
              errorDesc = firstDesc.replace('[clang]', finalLang);
            }else{
              errorDesc = firstDesc.replace('[clang]', finalLang);
            }
            finalErrorMsg = true;
          }
        }
      }

      //-- Check Invalid or Wrong Locale --//
      if (binLocaleStatus) 
      {
          let finalLocale:any;
          errorValue = static_data.INVALID_LOCALE_CODE;
          if (LangCodes == "") 
          {
            errorMsg = locData.MISSING_LOCALE_STATUS_TXT;
            errorDesc = locData.MISSING_LOCALE_STATUS_DESC;
            let strLocale = binLocale.toString();
            if(binLocale.length > 1){
              finalLocale = strLocale.replace(/,/g, " or ");
              errorDesc = errorDesc.replace('[fLocale]', finalLocale);
            }else{
              errorDesc = errorDesc.replace('[fLocale]', strLocale);
            }
            finalErrorMsg = true;
          }
          else if (LangCodes.length != 5) 
          { 
            errorMsg = locData.INVALID_LOCALE_CODE_TXT;
            console.log(errorMsg);
            errorDesc = locData.INVALID_LOCALE_LENGTH_DESC;
            finalErrorMsg = true;
            console.log("asdasdasdasdasdasd");
          }
          else if (!LangCodes.match(/^[a-zA-Z-]+$/)) 
          {
            errorMsg = locData.INVALID_LOCALE_CODE_TXT;
            errorDesc = locData.INVALID_LOCALE_ALPHA_DESC;
            finalErrorMsg = true;
          }
          else 
          {
            errorMsg = locData.INVALID_LOCALE_CODE_TXT;
            errorDesc = locData.INVALID_LOCALE_CODE_DESC;
            firstDesc = errorDesc.replace('[rlocale]', LangCodes);
            if(typeof LangCodes != "undefined")
            {
              if (!binLocale.includes(LangCodes))
              {
                let strLocale = binLocale.toString();
                if(binLocale.length > 1){
                  finalLocale = strLocale.replace(/,/g, " or ");
                  errorDesc = firstDesc.replace('[clocale]', finalLocale);
                }else{
                  errorDesc = firstDesc.replace('[clocale]', strLocale);
                }
                finalErrorMsg = true;
              }
            }
          }
        }

      if (isActive) 
      {
        errorValue = static_data.INVALID_WIDGET_CODE;
        errorMsg = locData.INVALID_WIDGET_STATUS_TXT;
        errorDesc = locData.INVALID_WIDGET_STATUS_DESC;
        finalErrorMsg = true;
      }
    }
    let nestjs_server_url = process.env.NEST_SERVER_URL;
    if (finalErrorMsg) {
      return { 'errorCode': true, errorValue, errorMsg, errorDesc, hashKey, countryName, brandName, productEAN, nestjs_server_url};
    } else {
      const existingWidget = await this.widgetModel
        .aggregate([
          {
            $match: {
              $and:
              [
                {
                  $or: 
                  [
                    { language_code: { $regex: lang_code } },
                    { locale: lang_code },
                  ]
                },
                {
                   $or: 
                   [
                     { product_ean: hash_key },
                     { hash_key: hash_key }
                   ]
                }
              ]
            },
          },
          {
            $lookup: {
              from: 'bin_theme_config',
              localField: 'brand_code',
              foreignField: 'brand_code',
              as: 'bindata',
            },
          },
          {
            $unwind: "$bindata"
          },
          {
            $project: {
              product_sku: 1,
              product_id: 1,
              brand_name: 1,
              widget_name: 1,
              product_ean: 1,
              product_image_url: 1,
              product_description: 1,
              language_code: 1,
              brand_keyword: 1,
              country: 1,
              country_code: 1,
              locale:1,
              brand_code:1,
              hash_key:1,
              css_classes: 
              {
                  $cond: {
                      if:{$eq: ["$bindata.status",true]},
                      then:"$bindata.css_classes",
                      else:""
              }},
              brandsites: 
              {
                $filter: {
                  input: "$bindata.brandsites",
                  as: "childcss",
                  cond: {
                      $and:[{$eq: ["$$childcss.brand_name",brandName]},{$eq: ["$$childcss.status",true]}],
                    }
                }
              },
            }
          }
        ]).exec();
      if(existingWidget.length > 0){
        if(existingWidget[0].brandsites!='' && existingWidget[0].brandsites[0].css_classes!=''){
          existingWidget[0].css_classes = existingWidget[0].brandsites[0].css_classes;
        }
        delete existingWidget[0].brandsites;
      }else{
        errorValue = static_data.NOT_EXIST_THEME_CODE;
        errorMsg = locData.NOT_EXIST_BRAND_THEME_TXT;
        errorDesc = locData.NOT_EXIST_BRAND_THEME_DESC;
        return { 'errorCode': true, errorValue, errorMsg, errorDesc, hashKey, countryName, brandName, productEAN, nestjs_server_url};
      }
      return existingWidget[0];
    }
  }

  /*
  * @created  : April 12, 2023
  * @modified : April 12, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The function retrieves the lowest price information for a given key value by fetching and processing data from various sources, including the BIN schema, retailer information service, and localization data
  * @params   : keyVal, langCode 
  * @return   : Response
  */

  async getLowestPrice(keyVal: String, langCode: String) 
  {
    let proRetRawInfo: any;
    let binInfo: any;
    let brandData:any;
    let jsondata: any;
    let arrLowestData: any;
    let priceNum: any;
    let priceStr: any;
    let lowestPrice = null;
    let lowestValue = Infinity;

    if (keyVal != '') 
    {
      jsondata = this.datamodel.t(`locale`, { lang: `${langCode}` || 'en' });
      arrLowestData = { "lowest_data": { price_symbol_position:true, buy_now_custom_text: jsondata.BUY_NOW_CUSTOM_TXT, "price_symbol": "","lowest_price":""}};
      //-- Fetch BIN Data and BIN Theme Information from BIN Schema Based on Hash Key --//
      try {
        binInfo = await this.widgetModel.aggregate([
          {
            $match: {
              $and: [
                { $or: [{ 'product_ean': keyVal }, { 'hash_key': keyVal }] },
                { 'language_code': { '$regex': langCode } }
              ]
            }
          },
          {
            $project: {
              'product_sku': 1,
              'brand_name': 1,
              'country': 1
            }
          }
        ]).exec();

        //-- Global & Country Data --//
        let globalData = await this.RetailerInfoService.countryInfo('All');  
        let countryData = await this.RetailerInfoService.countryInfo(binInfo[0].country);
        if (binInfo[0].brand_name) 
        {
          brandData = await this.RetailerInfoService.brandInfo(binInfo[0].brand_name);
        }

        proRetRawInfo = await this.RetailerInfoService.lowestPriceData(binInfo[0].product_sku, binInfo[0].brand_name);
        if (proRetRawInfo.length > 0)
        {
          for (const data of proRetRawInfo) {
            let priceData = data.retailer_product_price.replace(/[^0-9,.]+/g, '');
            priceData = await this.RetailerInfoService.priceInfo(priceData,'','rFormat');
            priceStr = await this.RetailerInfoService.getValidPrice(priceData);
            priceNum = Number(priceStr);
            if (priceNum < lowestValue) {
              lowestValue = priceNum;
              lowestPrice = { lowestValue:priceData, curSymbol: data.retailerdata[0].currency_symbol };
            }
          }

          let priceStatus =  await this.RetailerInfoService.checkStatus(globalData.show_price,countryData.show_price,brandData.show_price);
          let showpsPosition = await this.RetailerInfoService.checkStatus(globalData.price_symbol_position,countryData.price_symbol_position,brandData.price_symbol_position);
          let psStatus = (showpsPosition == '1') ? true : false;
          if ((priceStatus == '1') && (lowestPrice)) {
            arrLowestData.lowest_data.price_symbol_position = psStatus;
            arrLowestData.lowest_data.price_symbol = lowestPrice.curSymbol;
            arrLowestData.lowest_data.lowest_price = lowestPrice.lowestValue;
          }
        } 
        return arrLowestData;
      } catch (error) {
        return arrLowestData;
      }
    }
  }
}
