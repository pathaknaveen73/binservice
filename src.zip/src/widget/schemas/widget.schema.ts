import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({ collection: 'bin_data' ,autoCreate: false,})
export class Widget {
  @Prop()
  widget_name:String;

  @Prop()
  hash_key: String;

  @Prop()
  product_cw_id: String;

  @Prop()
  product_sku: String;

  @Prop()
  status: Boolean;
}

export const WidgetSchema = SchemaFactory.createForClass(Widget);
