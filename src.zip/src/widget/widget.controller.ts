import {
  Controller,
  Get,
  Param,
} from '@nestjs/common';
import { WidgetService } from './widget.service';
import { ApiExcludeEndpoint } from '@nestjs/swagger';

@Controller('widget')
export class WidgetController {
  constructor(private readonly widgetService: WidgetService,
  ) {}

  //-- The purpose of this function is to handle an HTTP GET request to retrieve a widget based on a provided hash key and language code --//
  @Get(':hash_key/:lang_code/:widget_theme')
  @ApiExcludeEndpoint()
  findOne(
    @Param('hash_key') hash_key: string,
    @Param('lang_code') lang_code: string,
  ) {
    return this.widgetService.findOne(hash_key, lang_code); 
  }
}
