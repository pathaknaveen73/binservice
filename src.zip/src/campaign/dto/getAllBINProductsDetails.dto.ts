import { ApiProperty } from "@nestjs/swagger";

export class getAllBINProductsDetailsDto {
    @ApiProperty()
    campaign_id: String;
}
