import { ApiProperty } from '@nestjs/swagger';
export class postBinProductDetailDto {

  @ApiProperty()
  smartkey_data: String;

  @ApiProperty()
  country_id: String;

  @ApiProperty()
  brand_id: String;

  @ApiProperty()
  campaign_name: String;

  @ApiProperty()
  campaign_id: String;

  @ApiProperty()
  language_code: String;
}
