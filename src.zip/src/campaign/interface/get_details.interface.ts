import { Document } from 'mongoose';
export interface IgetDetalis extends Document {
    readonly product_ean: String;
    readonly language_code: String;
    readonly country_code: String;
}