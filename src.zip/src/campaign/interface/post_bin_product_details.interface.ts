import { Document } from 'mongoose';
export interface IpostBinProductDetail extends Document {
    readonly brand_url: String;
}