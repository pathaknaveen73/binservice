import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({ collection: 'campaign', autoCreate: false,versionKey: false})
export class postBinProductDetail{
  @Prop()
  smartkey_data: String;

  @Prop()
  country_id: String;

  @Prop()
  brand_id: String;

  @Prop()
  campaign_name: String;

  @Prop()
  campaign_id: String;

  @Prop()
  language_code: String;
  
  @Prop()
  created_on: Date;

  @Prop()
  modified_on: Date;

  @Prop()
  is_active: Boolean;

  @Prop([{
    smartkey_data : String,
  }])
  campaign_products:{
    smartkey_data: String;
  }[]


}

export const postBinProductDetailSchema = SchemaFactory.createForClass(postBinProductDetail);
