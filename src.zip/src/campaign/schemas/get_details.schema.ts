import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({ collection: 'bin_data', autoCreate: false,versionKey: false})
export class getDetalis{
  @Prop()
  product_ean: String;

  @Prop()
  country_code: String;

  @Prop()
  language_code: String;

}

export const getDetalisSchema = SchemaFactory.createForClass(getDetalis);
