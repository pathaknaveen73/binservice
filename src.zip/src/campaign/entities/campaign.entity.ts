export class Campaign {}
