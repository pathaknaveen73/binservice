import { Test, TestingModule } from '@nestjs/testing';
import { CwApiService } from './cw_api.service';

describe('CwApiService', () => {
  let service: CwApiService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [CwApiService],
    }).compile();

    service = module.get<CwApiService>(CwApiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
