import { Inject, Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { IpostBinProductDetail } from './interface/post_bin_product_details.interface';
import { Model } from 'mongoose';
import { ObjectId } from 'mongodb'
import { ErrorCodeService } from '../error_code/error_code.service';
import { IBrandInfo } from '../retailer_info/interface/brand_info.interface';
import { ICountryInfo } from '../retailer_info/interface/country_info.interface';
import { IgetDetalis } from './interface/get_details.interface';


@Injectable()
export class CampaignService {
  constructor(
    @InjectModel('postBinProductDetail', 'cw_widgets')
    private cwWidgetsModel: Model<IpostBinProductDetail>,
    @InjectModel('CountryData', 'cwScrapingDB')
    private counteryInfoModel: Model<IBrandInfo>,
    @InjectModel('BrandInfo', 'cwScrapingDB')
    private brandInfoModel: Model<ICountryInfo>,
    @InjectModel('getDetalis', 'cw_widgets')
    private getDetalisModel: Model<IgetDetalis>,
    @Inject(ErrorCodeService)
    private readonly ErrorCodeService: ErrorCodeService,
  ) { }

  /*
  * @created : May 6, 2023
  * @author  : Vishal Nigam
  * @access  : private
  * @Purpose : This API is used to provide a list of active countries
  * @params  : country
  * @return  : Response
  */

  async getActiveCountries(countryId = null) 
  {
    try {
      if (countryId) 
      {
        const queryC = await this.counteryInfoModel.aggregate([
          {
            $match: {
              $and: [
                { _id: new ObjectId(countryId)},
                { is_active: true }
              ]
            }
          },
          {
            $project: {
              _id: 0,
              id: { $toString: '$_id' },
              country: '$name',
              iso_country_code: '$country_code'
            }
          },
          {
            $sort: { 'country': 1 }
          }
        ]);

        if (!queryC.length) {
          return '{"responseCode":400,"message":"Records not found"}';
        }
        return queryC;
      } 
      else 
      {
          const queryC = await this.counteryInfoModel.aggregate([
            {
            $match: {
              is_active: true
            }
          },
          {
            $project: {
              _id: 0,
              id: { $toString: '$_id' },
              country: '$name',
              iso_country_code: '$country_code'
            }
          },
          {
            $sort: { country: 1 }
          }
        ]);
        if (!queryC.length) {
          return '{"responseCode":400,"message":"Records not found"}';
        }
        return queryC;
      }
    }
    catch {
      return '{"responseCode":400,"message":"Country not Found"}';
    }
  }
  
    /*
   * @created : May 8, 2023
   * @author  : Vishal Nigam
   * @access  : private
   * @Purpose : This API is used to Retrieve the complete list of active brands across all countries.
   * @params  : country
   * @return  : Response
   */

    async getActiveBrands(country = null) 
    {
      try {
        if (country) {
          country = decodeURIComponent(country);
          const regex = new RegExp(country, 'i');
          const queryC = await this.counteryInfoModel.aggregate([
            { $match: { name: { $regex: regex } } },
            { $project: { _id: 1 } },
            { $limit: 1 }
          ]);
          const countryID = queryC[0]._id.toString();
          const queryB = await this.brandInfoModel.aggregate([
            {
              $match: {
                $and: [
                  { country_id: new ObjectId(countryID) },
                  { is_active: true }
                ]
              }
            },
            {
              $project: {
                _id: 0,
                brandId: { $toString: '$_id' },
                brand: { $split: ['$brand_name', ' - '] },
                countryId: { $toString: '$country_id' },
                brandSort: '$brand_name',
                brand_code: 1
              }
            },
            {
              $group: {
                _id: { brand_code: '$brand_code' },
                brandSort: { $first: '$brandSort' },
                brandId: { $first: '$brandId' },
                brand: { $first: { $arrayElemAt: ['$brand', 0] } },
                countryId: { $first: '$countryId' }
              }
            },
            { $sort: { brand: 1 } }
          ]);
          if (!queryB.length) {
            return '{"responseCode":400,"message":"Records not found"}';
          }
          return queryB;
        }
        else {
          const queryB = await this.brandInfoModel.aggregate([
            {
              $match: {
                is_active: true
              }
            },
            {
              $project: {
                _id: 0,
                brandId: { $toString: '$_id' },
                brand: { $arrayElemAt: [{ $split: ['$brand_name', ' - '] }, 0] },
                countryId: { $toString: '$country_id' },
                brandSort: '$brand_name'
              }
            },
            { $sort: { brand: 1 } }
          ]);
  
          if (!queryB.length) {
            return '{"responseCode":400,"message":"Records not found"}';
          }
          return queryB;
        }
      }
      catch {
        return '{"responseCode":400,"message":"Brands not Found"}';
      }
    }
  
 /*
  * @created : May 9, 2023
  * @author  : Vishal Nigam
  * @access  : private
  * @Purpose : This API is designed to retrieve a list of language codes and locales associated with a given brand and country
  * @params  : brand_id, country_id
  * @return  : Response
  */

  async getLanguageLocaleList(brand_id: any, country_id: any) 
  {
    let language_id: any;
    let countryResult: any;
    let languageIdResult: any;
    let locale: any;
    let languageCode: any;
    let data = [];
    try {

      if (brand_id && country_id) 
      {
        languageIdResult = await this.brandInfoModel.aggregate([
          { $match: { '_id': new ObjectId(brand_id) } },
          {
            $project: {
              '_id': 1,
              'countryId': '$country_id',
              'language_id': 1
            }
          }
        ]).exec();
        language_id = languageIdResult[0].language_id;
        countryResult = await this.counteryInfoModel.aggregate([
          {
            $match: { $and: [{ 'languages.id': language_id }, { '_id': new ObjectId(country_id) }] }
          },
          {
            $project: {
              '_id': 1,
              'languages.iso_code': 1,
              'country_code': 1,
              'languages.code': 1,
              'langSort': '$languages.iso_code'
            }
          },
          {
            $sort: { 'langSort': 1 }
          }
        ])

        if (countryResult.length != 0) 
        {
          locale = [countryResult[0].languages[0].code + "-" + countryResult[0].country_code, countryResult[0].languages[0].iso_code + "-" + countryResult[0].country_code]
          languageCode = [countryResult[0].languages[0].code, countryResult[0].languages[0].iso_code];

          let uniqueLocale = locale.filter((value: any, index: any, array: string | any[]) => array.indexOf(value) === index);
          let uniquelang = languageCode.filter((value: any, index: any, array: string | any[]) => array.indexOf(value) === index);

          let length = uniqueLocale.length;
          for (let i = 0; i < length; i++) {
            data.push({ "locale": uniqueLocale[i], "languageCode": uniquelang[i] });
          }
          return { "data": data };
        }
        else 
        {
          return { "responseCode": 400,"message": "No data Found" };
        }
      }
    }
    catch (err) {
      return { "responseCode": 400,"message": "No data Found" };
    }
  }
  
  /*
  * @created : May 10, 2023
  * @author  : Vishal Nigam
  * @access  : private
  * @Purpose : This API is used to retrieves widget details based on the EAN, country ID, and language code. 
  * @params  : ean_no, country_id, lang_code
  * @return  : Response
  */
  
  async getWidgetDetails(ean_no: any, country_id: any, lang_code: any) 
  {
    let result: any;
    let countryData: any;
    let response: any
    try {
      if ((ean_no && country_id && lang_code) && (ean_no != '' && country_id != '' && lang_code != '')) 
      {
        countryData = await this.counteryInfoModel.aggregate(
          [
            { $match: { '_id': new ObjectId(country_id) } },
            { $project: { '_id': 1, 'country_code': 1 } }
          ]
        );

        let regex = new RegExp(lang_code, 'i');
        result = await this.getDetalisModel.aggregate([
          {
            $match: { $and: [{ 'product_ean': ean_no }, { 'country_code': countryData[0].country_code }, { 'language_code': regex }] }
          },
          {
            $project: {
              '_id': 0,
              'product_id': '$product_sku',
              'productTitle': '$widget_name',
              'image_url': '$product_image_url',
              'smart_prduct_id': '$hash_key'
            }
          }
        ]).exec();
      }
      else if (ean_no && (lang_code == null || lang_code == '' || country_id == null || country_id == '' )) 
      {
        result = await this.getDetalisModel.aggregate(
          [
            { $match: { 'product_ean': ean_no } },
            {
              $project: {
                '_id': 0,
                'product_id': '$product_sku',
                'productTitle': '$widget_name',
                'image_url': '$product_image_url',
                'smart_prduct_id': '$hash_key'
              }
            }
          ]
        ).exec();
      }
      if (result && result.length != 0) {
        response = {
          "responseCode": 200,
          "message": "Data Available",
          "data": result
        }
        return response;
      }
      else {
        response = {
          "responseCode": 400,
          "message": "No data Found",
        }
        return response;
      }
    }
    catch (err) {
      response = {
        "responseCode": 400,
        "message": "No data Found",
      }
      return response;
    }
  }

 /*
  * @created  : May 11, 2023
  * @modified : May 12, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : This API receives an HTTP POST request to add or update product details related to a campaign from MongoDB database and return the BIN Widget Details
  * @params   : smartkey_data, country_id, brand_id, campaign_name, campaign_id, language_code
  * @return   : Response
  */

  async getBINProductDetails(post: { smartkey_data: any; country_id: any; brand_id: any; campaign_name: any; campaign_id: any; language_code: any; }) 
  {
    try 
    {
      let smartkey_data = post.smartkey_data;
      let country_id = post.country_id;
      let brand_id = post.brand_id;
      let campaign_name = post.campaign_name;
      let campaign_id = post.campaign_id;
      let language_code = post.language_code;
      const date = new Date();
      let timestamp = new Date(date.getTime());

      if (smartkey_data && country_id && brand_id && campaign_name && campaign_id && language_code) 
      {
        let campaignData = await this.cwWidgetsModel.aggregate([
          {
            $match: { 'campaign_id': campaign_id }
          },
          {
            $project: { '_id': 1, 'brand_id': 1 }
          }
        ]).exec();

        if (campaignData.length == 0) 
        {
          let campaignJson = {
            'campaign_id': campaign_id,
            'campaign_name': campaign_name,
            'country_id': country_id,
            'brand_id': brand_id,
            'created_on': new Date(timestamp),
            'modified_on': new Date(timestamp),
            'is_active': true,
            'language_code':language_code,
            'campaign_products': [{ 'smartkey_data': smartkey_data }],
          };

          await this.cwWidgetsModel.create(campaignJson);
        }
        else 
        {
          let condition = { '_id': new Object(campaignData[0]._id) };
          let campaignJson = {
            'campaign_id': campaign_id,
            'campaign_name': campaign_name,
            'country_id': country_id,
            'brand_id': brand_id,
            'modified_on': new Date(timestamp),
            'is_active': true,
            'language_code':language_code,
            'campaign_products': [{ 'smartkey_data': smartkey_data }],
          };

          await this.cwWidgetsModel.updateOne(condition, { '$set': campaignJson });
        }

          let campaignDataResult = await this.cwWidgetsModel.aggregate([
          {
            $match: { 'campaign_id': campaign_id }
          },
          {
            $project: { '_id': 1, 'brand_id': 1, 'country_id': 1, 'campaign_id': 1, 'campaign_products.smartkey_data': 1 }
          }
        ]).exec();

        for (const [datakey, data] of Object.entries(campaignDataResult)) 
        {
          let smartkey = data.campaign_products[0].smartkey_data;
          let smartkeys = smartkey.split(",");
          let length = smartkeys.length;
          let items = [];

          for (let i = 0; i < length; i++) 
          {
            let key = smartkeys[i].trim();
            let response_data = await this.ErrorCodeService.findOne(key, language_code, campaign_id);
            items.push({});
            items[i][key] = [];
            items[i][key].push({
              'smart_product_key': key,
            });
            if(!response_data.errorCode)
            {
              items[i][key].push(
                {"product": [response_data]} 
              );
            }
            else{
              items[i][key].push(
                {"product": []} 
              );
            }
          }

          let myjson = {
            "responseCode": 200,
            "message": "Data Saved Successfully",
            items,
          }

          return myjson;
        }
      }
      else 
      {
        return '{"responseCode":400,"message":"Missing Required Json Parameters"}';
      }
    }
    catch {
      return '{"responseCode":400,"message":"Widget not Found"}';
    }
  }

   /*
  * @created  : May 15, 2023
  * @modified : May 16, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : This API retrieves product details from a MongoDB database based on a given campaign ID 
  * @params   : campaign_id
  * @return   : Response
  */

   async getCampaignBINProductDetails(post: { campaign_id: any; })
   {
     try
     {
       const Campaign_Id = post.campaign_id;
       const Campaign_Id_Array = Campaign_Id.replace(/'/g, '').split(',');
       if (Campaign_Id_Array.length > 0) 
       {
           let queryPrms = { '$and':[{'campaign_id': {'$in':Campaign_Id_Array} }]};
           let FindSmartKeyObj = await this.cwWidgetsModel.aggregate([{'$match' : queryPrms}, 
           {
             $project : {
             '_id ': 1,
             'brand_id' : 1,
             'country_id' : 1,
             'campaign_id': 1,
             'language_code':1,
             'campaign_products.smartkey_data' : 1
             }
           }]).exec()
           if (FindSmartKeyObj.length > 0) 
           {
             let TotalSmartkeysArray = [];
             let SmartKeysObjlen = FindSmartKeyObj.length;
             let count=0;
             let items= [];
             for(let j=0; j<SmartKeysObjlen; j++)
             {
               let campLangCode=FindSmartKeyObj[j].language_code;
               const TotalSmartkey = FindSmartKeyObj[j].campaign_products[0].smartkey_data.split(",");
               let KeysCount = TotalSmartkey.length;
               for(let i=0; i<KeysCount; i++)
               {
                 let key = TotalSmartkey[i].trim();
                 TotalSmartkeysArray.push(key);
                 if(key !='' && campLangCode!='')
                 {
                    let response_data = await this.ErrorCodeService.findOne(key, campLangCode, Campaign_Id);
                    items.push({});
                    items[count][key]=[];
                    items[count][key].push({
                      'smart_product_key':key,
                    });
                    if(!response_data.errorCode)
                    {
                      items[count][key].push(
                        {"product": [response_data]} 
                      );
                    }
                  }
                  count++;
                }
              }
              let TotalSmartkeysStr = TotalSmartkeysArray.join();
              let myjson = {
                 "responseCode":200,
                 "message":"Data Saved Successfully",
                 "SmartProductKeys":TotalSmartkeysStr,
                 items,
               }
             return  myjson; 
            }
            else
            {
              return {"responseCode":400,"message":"campaign_id Not Found"};
            }
       }
       else
       {
         return {"responseCode":400,"message":"Missing Parameter campaign_id"};
       }
     }
      catch(err){
       return {"responseCode":400,"message":"No Data Found"};
     }
   }
}
