import { Module } from '@nestjs/common';
import { CampaignService } from './campaign.service';
import { CampaignController } from './campaign.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { postBinProductDetailSchema } from './schemas/post_bin_product_details.schema'
import { ErrorCodeModule } from '../error_code/error_code.module';
import { CountryDataSchema } from '../retailer_info/schema/country_info.schema';
import { BrandDataSchema } from '../retailer_info/schema/brand_info.schema';
import { getDetalisSchema } from './schemas/get_details.schema';

@Module({
  imports:[
    MongooseModule.forRoot(process.env.DB_CONNECT, {connectionName:'cwScrapingDB'}),
    MongooseModule.forFeature([
      { name:'CountryData', schema:CountryDataSchema},
      { name: 'BrandInfo', schema: BrandDataSchema }],'cwScrapingDB'),
    MongooseModule.forRoot(process.env.DB_CONNECT, {connectionName:'cw_widgets'}),
    MongooseModule.forFeature([
      { name:'postBinProductDetail', schema:postBinProductDetailSchema},
      { name:'getDetalis', schema:getDetalisSchema}],'cw_widgets'),
    ErrorCodeModule
  ],
  controllers: [CampaignController],
  providers: [CampaignService]
})
export class CampaignModule {}
