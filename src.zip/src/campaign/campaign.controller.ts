import { Controller, Get, Post, Body, Param, Query } from '@nestjs/common';
import { CampaignService } from './campaign.service';
import { postBinProductDetailDto } from './dto/postBinProductDetail.dto';
import { getAllBINProductsDetailsDto } from './dto/getAllBINProductsDetails.dto';
import { ApiParam, ApiQuery } from '@nestjs/swagger';

@Controller('campaign')
export class CampaignController {
constructor(private readonly CampaignService: CampaignService) {}

//-- The purpose of the brandOne function is to handle a GET request to the endpoint --//
 @Get('get_active_brands/:country?')
 @ApiParam({ name: 'country', required: false })
 brandOne(@Param('country') country: any){
  country = (country == ',')?"":country;
  if(country){
    return this.CampaignService.getActiveBrands(country);
  }else{
    return this.CampaignService.getActiveBrands();
  }
}

//-- The purpose of the countryOne function is to handle a GET request to the endpoint --//
@Get('get_active_countries/:countryId?')
@ApiParam({ name: 'countryId', required: false })
countryOne(@Param('countryId') countryId: any){
  countryId = (countryId == ',')?"":countryId;
  if(countryId){
    return this.CampaignService.getActiveCountries(countryId);
  }else{
    return this.CampaignService.getActiveCountries();
  }
 }

//-- The purpose of the findAll function is to handle a GET request to the endpoint --//
@Get('get_widget_details')
@ApiQuery({ name: 'country_id', required: false })
@ApiQuery({ name: 'lang_code', required: false })
  findAll(@Query('ean_no') ean_no: string,
  @Query('country_id') country_id: string,
  @Query('lang_code') lang_code: string
  ) {
    return this.CampaignService.getWidgetDetails(ean_no,country_id,lang_code);
  }

 //-- The purpose of the getLanguageCode function is to handle a GET request to the endpoint --//
  @Get('get_language_locale_list/:brand_id/:country_id')
  getLanguageCode(
    @Param('brand_id') brand_id: string,
    @Param('country_id') country_id: string
  ) {
    return this.CampaignService.getLanguageLocaleList(brand_id,country_id);
  }

  //-- The purpose of the create function is to handle a POST request to the endpoint --//
  @Post('get_bin_product_details')
  create(@Body() postBinProductDetailDto: postBinProductDetailDto) {
    return this.CampaignService.getBINProductDetails(postBinProductDetailDto);
  }

  //-- The purpose of the pdetails function is to handle a POST request to the endpoint --// 
  @Post('get_campaign_bin_product_details')
  pdetails(@Body() getAllBINProductsDetailsDto: getAllBINProductsDetailsDto) {
    return this.CampaignService.getCampaignBINProductDetails(getAllBINProductsDetailsDto);
  }
}
