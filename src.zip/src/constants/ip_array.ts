const blocked_ip_array = ['115.242.209.74','103.245.34.226','127.0.0.1','::1']
export default blocked_ip_array;