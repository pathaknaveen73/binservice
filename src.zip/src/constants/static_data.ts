const static_data = 
{
    "MISSING_SMARTID_CODE": "105",
    "MISSING_EAN_CODE": "109",
    "INVALID_PRODUCT_CODE": "101",
    "INVALID_PRODUCT_EAN": "106",
    "INVALID_LANGUAGE_CODE": "103",
    "INVALID_WIDGET_CODE": "104",
    "NOT_EXIST_THEME_CODE":"102",
    "INVALID_LOCALE_CODE": "107",
    "INVALID_PRODUCT_SKU_CODE": "108",
    "CONTACT": "deepak.verma@srmtechsol.com",
    "CATEGORY": "121",
    "SUBCATEGORY": "601",
    "IMPACT": "4-Low",
    "URGENCY": "3-Low",
    "SHORT_DESCRIPTION_101": "BIN button is not working on brand website because of incorrect SmartProductId.",
    "DESCRIPTION_101": "There is a problem with one of the products Buy It Now (BIN) button on PDP_URL. BIN button is not working because SmartProductId is incorrect. Please check that PIM sheet has correct SmartproductId for the product which should look something like this HASH_KEY. If not sure, log a Kana ticket for support here https://udhd.service-now.com/csm?id=csm_get_help&sys_id=990686831b3cc0d076bc6428bd4bcba2",
    "SHORT_DESCRIPTION_105": "BIN button is not working on brand website because of missing SmartProductId.",
    "DESCRIPTION_105": "There is a problem with one of the products Buy It Now (BIN) button on PDP_URL. BIN button is not working because SmartProductId is missing. Please check that PIM sheet has a SmartproductId for the product which looks something like this HASH_KEY, and it is being correctly passed to Cartwire widget in the code. If the ID is missing, log a Kana ticket to onboard the product on Cartwire here https://udhd.service-now.com/csm?id=sc_cat_item&sys_id=037002af1b851090cd9b1028bd4bcbe1",
    "SHORT_DESCRIPTION_102": "BIN button is not working on brand website because of invalid widget Theme.",
    "DESCRIPTION_102": "There is a problem with Buy It Now (BIN) button on PDP_URL. BIN button is not working because incorrect value for theme type is being passed to Cartwire widget. Ask the agency to pass correct parameter. In most cases it is retailPopup but if not working or not sure what parameter to pass, reach out to Cartwire team.",
    "SHORT_DESCRIPTION_103": "BIN button is not working on brand website because of incorrect language code.",
    "DESCRIPTION_103": "There is a problem with Buy It Now (BIN) button on PDP_URL. BIN button is not working because incorrect language id is being passed to the widget. Currently it is passing language code as en whereas widget is configured to accept fr",
}

export default static_data;