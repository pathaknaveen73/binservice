import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import { ErrorCodeService } from './error_code.service';
import { ErrorCodeController } from './error_code.controller';
import { WidgetService } from '../widget/widget.service';
import { WidgetModule } from '../widget/widget.module';
import { RetailerInfoModule } from '../retailer_info/retailer_info.module';
import { AcceptLanguageResolver, I18nModule, QueryResolver } from 'nestjs-i18n';
import { LoggerMiddleware } from '../common/middleware/logger.middleware';
import { join } from 'path';
import { CacheModule, CacheInterceptor } from '@nestjs/cache-manager';
import { APP_INTERCEPTOR } from '@nestjs/core';

@Module({
  imports: [
    CacheModule.register({
      ttl: 10, // Max age 4 sec
      max: 5000, // maximum number of items in cache
    }),
    WidgetModule,
    RetailerInfoModule,
    I18nModule.forRoot({
      fallbackLanguage: 'EN',
      loaderOptions: {
        path: join(__dirname, '..', '/i18n/'),
        watch: true,
      },
      resolvers: [
        { use: QueryResolver, options: ['lang'] },
        AcceptLanguageResolver,
      ],
    })
  ],
  controllers: [ErrorCodeController],
  providers: [ErrorCodeService, {
    provide: APP_INTERCEPTOR,
    useClass: CacheInterceptor,
  }],
  exports: [ErrorCodeService]
})
export class ErrorCodeModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(LoggerMiddleware)
      .forRoutes('*');
  }
}