import { Injectable, Inject } from '@nestjs/common';
import { WidgetService } from '../widget/widget.service';
import { RetailerInfoService } from '../retailer_info/retailer_info.service';
import { I18nService } from 'nestjs-i18n';

@Injectable()
export class ErrorCodeService {
  constructor(
  @Inject(WidgetService)
  private readonly widgetService: WidgetService,
  @Inject(RetailerInfoService)
  private readonly RetailerInfoService: RetailerInfoService,
  private readonly datamodel: I18nService
  ) { }
  
 /*
  * @created  : April 5, 2023
  * @modified : April 11, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The findOne method appears to be an asynchronous function that handles retrieving and formatting data for a widget based on the provided parameters
  * @params   : keyVal, langCode 
  * @return   : Response
  */

  async findOne(keyVal: any, langCode: any, campaign_id:any) 
  {
    let productSKU: any, brandName: any, brandKeyword: any, countryName: any, countryCode: any, widgetName: any, productEAN: any, product_image_url: any, imageURL: any, locData:any, gaId = "", reportSuiteId = "", 
    cssClasses = "", productDescription:any, widgetObj: any, globalData:any, countryData: any, brandData:any, showStoreLocator:any, countryList:any, country = [], countries = [],showDesc:any, msgTxt:any,
    storeStatus:any, showPriceColumn:any, showOfferColumn:any, pcStatus:any, ocStatus:any, showpsPosition:any, psStatus:any, imStatus:any, showFixedOrder:any, foStatus:any, showpReco:any, prStatus:any,storeCount:any, searchRadius:any,sdStatus:any,
    onlinePayload:any,descPayload:any,instorePayload:any,prPayload:any,countryStatus: any, countryPayload:any, hashCode:any, locale:any, languageCode:any, brandCode:any, nestServerURL:any, showAR:any, arStatus:any;
    let widgetData = await this.widgetService.findOne(keyVal, langCode);
    //-- Check for Locale --//
    if(langCode.includes("-")){
      langCode = langCode.split("-")[0];
    }
    let retailerData = [];
    if (widgetData.errorCode) {
      return {...widgetData}
    } else {
      hashCode = widgetData.hash_key;
      locale = widgetData.locale;
      languageCode = widgetData.language_code;
      brandCode = widgetData.brand_code;
      productSKU = widgetData.product_sku;
      brandName = widgetData.brand_name;
      brandKeyword = widgetData.brand_keyword;
      countryName = widgetData.country;
      countryCode = widgetData.country_code;
      widgetName = widgetData.widget_name;
      productEAN = widgetData.product_ean;
      product_image_url = widgetData.product_image_url;
      cssClasses = widgetData.css_classes;
      productDescription = widgetData.product_description.replace(/[\r\n\t ]+/g, ' ').trim().replace(/'/g, "\\'").replace(/"/g, '\\"');
      nestServerURL = process.env.NEST_SERVER_URL;
      
      //-- Image Configuration  --//
      imageURL = await this.RetailerInfoService.imageInfo(product_image_url);
      //-- End Here --//

      //-- Global & Country Data --//
      globalData = await this.RetailerInfoService.countryInfo('All');       
      countryData = await this.RetailerInfoService.countryInfo(countryName);
      brandData = await this.RetailerInfoService.brandInfo(brandName);
      retailerData = await this.RetailerInfoService.getRetailerInfo(productSKU, brandName, brandKeyword, langCode,campaign_id);

      //-- Localization --//
      locData = await this.RetailerInfoService.locale(langCode,brandData);
      
      //-- GA-ID & Report Suit ID ==//
      gaId = brandData.ga_id;
      reportSuiteId = brandData.report_suite_id;

      //-- Store Locator Configuration --//
      showStoreLocator = await this.RetailerInfoService.checkStatus(globalData.show_store_locator,countryData.show_store_locator,brandData.show_store_locator);
      storeStatus = (showStoreLocator == '1') ? true : false;

      //-- Price Column Configuration --//
      showPriceColumn = await this.RetailerInfoService.checkStatus(globalData.price_column,countryData.price_column,brandData.price_column);
      pcStatus = (showPriceColumn == '1') ? true : false;

      //-- Offer Column Configuration --//
      showOfferColumn = await this.RetailerInfoService.checkStatus(globalData.offer_column,countryData.offer_column,brandData.offer_column);
      ocStatus = (showOfferColumn == '1') ? true : false;
      
      //-- Price Symbol Position Configuration --//
      showpsPosition = await this.RetailerInfoService.checkStatus(globalData.price_symbol_position,countryData.price_symbol_position,brandData.price_symbol_position);
      psStatus = (showpsPosition == '1') ? true : false;
      
      //-- Image Alignment Configuration --//
      imStatus = await this.RetailerInfoService.checkStatus(globalData.img_align,countryData.img_align,brandData.img_align);
      
      //-- Retailer Fixed Order Configuration --//
      showFixedOrder = await this.RetailerInfoService.checkStatus(globalData.show_fixed_order,countryData.show_fixed_order,brandData.show_fixed_order);
      foStatus = (showFixedOrder == '1') ? true : false;
      
      //-- Production Recommendation Configuration --//
      showpReco = await this.RetailerInfoService.checkStatus(globalData.show_recommend_product,countryData.show_recommend_product,brandData.show_recommend_product);
      prStatus = (showpReco == '1') ? true : false;

      //-- Store Count and Radius Configuration --//
      storeCount = await this.RetailerInfoService.checkStatus(globalData.store_count,countryData.store_count,brandData.store_count);
      searchRadius = await this.RetailerInfoService.checkStatus(globalData.search_radius,countryData.search_radius,brandData.search_radius);
      
      //-- Show Description Configuration --//
      showDesc = await this.RetailerInfoService.checkStatus(globalData.show_description,countryData.show_description,brandData.show_description);
      sdStatus = (showDesc == '1') ? true : false;

      //-- Show Available Retailer Configuration --//
      showAR = await this.RetailerInfoService.checkStatus(globalData.show_available_retailers,countryData.show_available_retailers,brandData.show_available_retailers);
      arStatus = (showAR == '1') ? true : false;
      
      if(brandData.show_available_retailers == '1'){
        msgTxt = brandData.msg_text;
      }else if(countryData.show_available_retailers == '1'){
        msgTxt = countryData.msg_text; 
      }else{
        msgTxt = globalData.msg_text;
      }
        
      //-- Country Name & Code --//
      countryName = countryName;
      countryCode = countryCode;
      
      //-- Buy Online Payload --//
      onlinePayload = {
        "country_name": countryName,
        "country_code": countryCode,
        "ga_id": gaId ?? "",
        "report_suite_id": reportSuiteId ?? "",
        "brand_code": brandCode,
        "language_code": languageCode,
        "locale": locale,
        "smart_product_id": hashCode,
        "nestjs_server_url": nestServerURL ?? "",
        "show_store_locator": storeStatus,
        "price_column": pcStatus,
        "offer_column": ocStatus,
        "table_header": locData.TABLE_HEADER,
        "sort_by_price": locData.SORT_BY_PRICE,
        "price_symbol_position": psStatus,
        "brand_name": brandName,
        "widget_name": widgetName,
        "product_ean": productEAN,
        "product_sku": productSKU,
        "img_align": imStatus,
        "image_url": imageURL,
        "variant_text": locData.VARIANT_LEVEL_TXT,
        "close_txt": locData.CLOSE_TXT,
        "show_fixed_order": foStatus,
        "css_classes": cssClasses ?? "",
        "show_recommend_product": prStatus,
        "show_available_retailers": arStatus,
        "show_product_description":sdStatus,
        "unavailable_retailer_txt":msgTxt,
        "at_shop_following_retailers_txt": locData.AT_SHOP_FOLLOWING_RETAILERS_TXT,
        "shop_alternatives_txt": locData.SHOP_ALTERNATIVES_TXT
      }

      //-- Product Description Payload --//
      descPayload = {
        "product_description": productDescription ?? "", 
			  "purchase_option_txt": locData.PURCHASE_OPTION_TXT,
			  "product_txt": locData.PRODUCT_TXT
      }

      //-- Buy In Store Payload --//
      instorePayload = {
        "buy_online_txt": locData.BUY_ONLINE,
        "buy_in_store_txt": locData.BUY_IN_STORE,
        "nearest_store_txt": locData.NEAREST_STORE,
        "postal_address_txt": locData.POSTAL_ADDRESS,
        "current_location_txt": locData.CURRENT_LOCATION,
        "nearest_stores_txt": locData.NEAREST_STORES,
        "location_error_txt":locData.LOCATION_ERROR_TXT,
        "show_hide_txt": locData.SHOW_HIDE,
        "open_in_map_txt": locData.OPEN_IN_MAP,
        "search_txt": locData.SEARCH_TXT,
        "search_location_txt":locData.SEARCH_LOCATION,
        "metric_txt": locData.METRIC_TXT,
        "result_txt": locData.RESULT_TXT,
        "no_store_txt": locData.NO_STORE_TXT,
        "no_store_desc": locData.NO_STORE_DESC,
        "contact_txt": locData.CONTACT_TXT,
        "contact_url": brandData.contact_url ?? "",
        "store_count": storeCount,
        "search_radius": searchRadius,
        "store_loc_timing": locData.STORE_LOC_TIMING,
        "xapi":process.env.XAPI,
        "google_map_key":process.env.GOOGLE_MAP_KEY
      }
      
      //-- Product Recommendation Payload --//
      prPayload = {
        "no_alternative_product_available_txt": locData.NO_ALTERNATIVE_AVAILABLE_TXT,
        "recom_out_of_stock_txt": locData.RECOMMONDED_OUT_OF_STOCK_TXT
      }
      
      //-- Country Specific Payload --//
      if (brandData.country_based) 
      {
        if (langCode == 'ae') {
           langCode = 'ar';
        }
         
        //-- Country List for Drop-Down --//
        countryStatus = true;
        countryList = JSON.parse(brandData.country_list);
        country = [];
        countries = [];

        let i = 0;
        countryList[langCode].forEach((countryValue: {id: any; name: any; default: any; country_code: any}) => {
          if (countryValue.id['$oid']) {
            country.push({ id: countryValue.id['$oid'] });
          } else {
            country.push({ id: 0 });
          }
          country[i]['name'] = countryValue.name;
          country[i]['country_code'] = countryValue.country_code;
          country[i]['default'] = countryValue.default;
          i++;
        }); 
    
        countries['countries'] = country;
        countryPayload = countries;
      }
      
      if((storeStatus) && (sdStatus) && (countryStatus)){
        widgetObj = Object.assign(onlinePayload, instorePayload, descPayload, countryPayload);
      }else if((storeStatus) && (sdStatus)){
        widgetObj = Object.assign(onlinePayload, instorePayload, descPayload);
      }else if((storeStatus) && (countryStatus)){
        widgetObj = Object.assign(onlinePayload, instorePayload, countryPayload);
      }else if((storeStatus) && (prStatus)){
        widgetObj = Object.assign(onlinePayload, instorePayload, prPayload);
      }else if(countryStatus){
        widgetObj = Object.assign(onlinePayload, countryPayload);
      }else if(storeStatus){
        widgetObj = Object.assign(onlinePayload, instorePayload);
      }else if(sdStatus){
        widgetObj = Object.assign(onlinePayload, descPayload);
      }else if(prStatus){
        widgetObj = Object.assign(onlinePayload, prPayload);
      }else{
        widgetObj = onlinePayload;
      }

      widgetData = widgetObj;
    }
   
    let errorCode =  (retailerData as unknown as { errorCode: any }).errorCode;
    if(errorCode){
      return retailerData;
    }
    return { ...widgetData, 'retailer': retailerData }
  }

  /*
  * @created  : April 12, 2023
  * @modified : April 12, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The getLowestPrice method appears to be an asynchronous function that retrieves the lowest price for a widget based on the provided parameters
  * @params   : keyVal, langCode 
  * @return   : Response
  */

  async getLowestPrice(keyVal:any,langCode:any){
    return await this.widgetService.getLowestPrice(keyVal,langCode,false);
  }
}