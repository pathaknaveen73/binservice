import { Controller, Post, Get, UseInterceptors, Render, Req, Query, Inject, CACHE_MANAGER} from '@nestjs/common';
import { ErrorCodeService } from './error_code.service';
import { Request } from 'express';
import { CacheInterceptor } from '@nestjs/cache-manager';
import { ApiBody, ApiExcludeEndpoint } from '@nestjs/swagger';

@Controller('widget_price_theme_new_v1')
@UseInterceptors(CacheInterceptor)
export class ErrorCodeController {
  constructor(
    private readonly errorCodeService: ErrorCodeService,
    @Inject(CACHE_MANAGER) protected readonly cacheManager
    ) {}

  @ApiBody({ schema: { example: { keyVal: 'string', langCode: 'string'} } })

  //-- The purpose of the getData function is to handle a GET request to the endpoint --//
  @Get('getPriceRetailDynamicForm')
  getData(@Req() request: Request) {
    let widget_data = this.errorCodeService.findOne(request.query.keyVal, request.query.langCode, request.query.campaign_id);
    return widget_data;
  }
  
  //-- The purpose of the getWidget function is to handle a GET request to the endpoint and render a view using the template --//
  @Get('getPriceRetailDynamicFormWidget')
  @Render('layouts/main')
  @ApiExcludeEndpoint()
  getWidget(@Req() request: Request): object {
    let widget_data = this.errorCodeService.findOne(request.query.keyVal, request.query.langCode, request.query.campaign_id);
    return widget_data;
  }
  
  //-- The purpose of the find function is to handle a GET request to the endpoint --//
  @Get('getLowestPrice')
  find(@Query('keyVal') keyVal: string,
  @Query('langCode') langCode: string
  ){
   return this.errorCodeService.getLowestPrice(keyVal,langCode);
  }
  
  //-- The purpose of the find function is to handle a GET request to the endpoint --//
  @Post('clearAllCache')
  async clearAllCache(){
    await this.cacheManager.reset();
    return "Cache cleared successfully"
  }
}
