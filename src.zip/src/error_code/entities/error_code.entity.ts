export class ErrorCode {}
