import { Inject, Injectable } from '@nestjs/common';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { WidgetService } from '../widget/widget.service';

@Injectable()
export class ServicesService {
  constructor(
    @Inject(WidgetService)
    private readonly widgetService: WidgetService
  ) {}

  
/*
  * @created  : June 30, 2023
  * @modified : June 30git , 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : Function acts as a wrapper or proxy for the hashlanginfo method of the widgetService, allowing for asynchronous execution and returning the result obtained from that method call.
  * @params   : gtin, locale, brand_code (optional) 
  * @return   : Response
  */

async hashlanginfo(gtin: any, locale: any, brand_code: any){
  return await this.widgetService.hashlanginfo(gtin, locale, brand_code);
}
  
}
