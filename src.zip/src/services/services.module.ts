import { Module } from '@nestjs/common';
import { ServicesService } from './services.service';
import { ServicesController } from './services.controller';
import { WidgetModule } from '../widget/widget.module';

@Module({
  imports: [
    WidgetModule,
  ],
  controllers: [ServicesController],
  providers: [ServicesService]
 
})
export class ServicesModule {}