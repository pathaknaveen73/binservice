import { Controller, Get, Post, Body, Patch, Param, Delete, Query } from '@nestjs/common';
import { ServicesService } from './services.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { ApiQuery } from '@nestjs/swagger';

@Controller('services')
export class ServicesController {
  constructor(private readonly servicesService: ServicesService) {}

  //-- The purpose of this code defines an API endpoint that retrieves information about a product's language localization based on the provided GTIN, locale, and optionally the brand code. --//
  @Get('hashlanginfo')
  @ApiQuery({ name: 'brand_code', required: false })
  find(@Query('gtin') gtin: string,
  @Query('locale') locale: string,
  @Query('brand_code') brand_code: string,
  ){
   return this.servicesService.hashlanginfo(gtin,locale,brand_code);
  }
}