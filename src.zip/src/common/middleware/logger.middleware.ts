import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class LoggerMiddleware implements NestMiddleware {
    use(req: Request, res: Response, next: NextFunction) {

    //    if ( req.headers['user-agent'].length > 38 ) {
            res.setHeader("X-XSS-Protection", "1; mode=block");
            next();
    //    } else {
    //        res.sendStatus(403);
    //    }

    }
}
