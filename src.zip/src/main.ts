import { NestFactory } from '@nestjs/core';
import { NestExpressApplication } from '@nestjs/platform-express';
import { AppModule } from './app.module';
import { join } from 'path';
import { engine } from 'express-handlebars';
import cors_allowed_domain from './constants/cors'
import { recLength, eq, splitHead, getLink, toggleBtn, singleLineOnly } from './hbs/helpers';
import helmet from 'helmet';
import * as compression from 'compression';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(
    AppModule,
    { logger: ['error', 'warn', 'log'] },
  );

  const config = new DocumentBuilder()
    .setTitle('CartWire API Documentation')
    .setDescription('Cartwire is a new e-commerce solution for brands, enabling plug-and-play Buy It Now (BIN) functionality on web, social and mobile channels.')
    .setVersion('2.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api', app, document, {
    swaggerOptions: { defaultModelsExpandDepth: -1 },
  });

  app.enableCors({
    origin: cors_allowed_domain,
    methods: "GET,POST",
  });


  app.use(compression());
//  app.use(helmet.contentSecurityPolicy());
//  app.use(helmet.crossOriginEmbedderPolicy());
//  app.use(helmet.crossOriginOpenerPolicy());
//  app.use(helmet.crossOriginResourcePolicy());
  app.use(helmet.dnsPrefetchControl());
  app.use(helmet.expectCt());
  app.use(helmet.frameguard());
  app.use(helmet.hidePoweredBy());
  app.use(helmet.hsts());
  app.use(helmet.ieNoOpen());
  app.use(helmet.noSniff());
  app.use(helmet.originAgentCluster());
  app.use(helmet.permittedCrossDomainPolicies());
  app.use(helmet.referrerPolicy());
  app.use(helmet.xssFilter());

  // app.disable('x-powered-by');
  app.useStaticAssets(join(__dirname, '..', 'public'));
  app.setBaseViewsDir(join(__dirname, '..', 'views'));

  app.engine(
    'hbs',
    engine({
      extname: 'hbs',
      defaultLayout: 'main',
      layoutsDir: join(__dirname, '..', 'views', 'layouts'),
      partialsDir: join(__dirname, '..', 'views', 'partials'),
      helpers: {
        recLength,
        eq, toggleBtn, singleLineOnly,
        splitHead, getLink,
        sectionsplit: function (name, options) {
          return name[options];
        },
        isActive: (val, options) => {
          if (val === 3 || val === 0) {
            return options.fn(this)
          }
        },
        replace: function (find, replace, options) {
          var string = options.fn(this);
          return string.replace(find, replace);
        },
        ifCond: (v1, v2, options) => {
          if (v1 === v2) {
            return options.fn(this);
          }
          return options.inverse(this);
        },
        ifEquals: (arg1, arg2, options) => {

          return (arg1 == arg2) ? options.fn(this) : options.inverse(this);
        },
        section: function (name, options) {
          if (!this._sections) this._sections = {};
          this._sections[name] = options.fn(this);
          return null;
        }

      },

    }),
  );

  app.setViewEngine('hbs');

  app.use(compression());
  await app.listen(3000);
}
bootstrap();

/*
Update the WSL kernel by running "wsl --update" or follow instructions at 
https://docs.microsoft.com/windows/wsl/wsl2-kernel
*/