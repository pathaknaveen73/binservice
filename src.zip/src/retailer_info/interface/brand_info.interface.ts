import { Document } from 'mongoose';
export interface IBrandInfo extends Document {

}