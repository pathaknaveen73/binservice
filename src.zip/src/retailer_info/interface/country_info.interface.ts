import { Document } from 'mongoose';
export interface ICountryInfo extends Document {
  readonly name: String;
  readonly show_price: String;
  readonly show_offer: String;
  readonly show_available_retailers: String;
  readonly display_msg: String;
  readonly msg_text: String;
  readonly show_fixed_order: String;
  readonly img_align: String;
  readonly price_symbol_position: String;
  readonly price_column: String;
  readonly show_recommended_product: String;
  readonly show_store_locator: String;
  readonly search_radius: String;
  readonly store_count: String;
  readonly enable_decimal_value: String;
}