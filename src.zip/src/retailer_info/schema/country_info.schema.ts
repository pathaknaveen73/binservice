import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, ObjectId } from 'mongoose';

export type CountryDataDocument = HydratedDocument<CountryData>;

@Schema({ collection: 'country_config' ,autoCreate: false})
export class CountryData {
  @Prop() 
  name: String;

  @Prop() 
  show_price: String;
  
  @Prop() 
  show_offer: String;
  
  @Prop() 
  show_available_retailers: String;
  
  @Prop() 
  display_msg: String;
  
  @Prop() 
  msg_text: String;
  
  @Prop() 
  show_fixed_order: String;
  
  @Prop() 
  img_align: String;
  
  @Prop() 
  price_symbol_position: String;
  
  @Prop() 
  price_column: String;
  
  @Prop() 
  show_recommended_product: String;
  
  @Prop() 
  show_store_locator: String;
  
  @Prop() 
  search_radius: String;
  
  @Prop() 
  store_count: String;
  
  @Prop() 
  enable_decimal_value: String;
}

export const CountryDataSchema = SchemaFactory.createForClass(CountryData);
