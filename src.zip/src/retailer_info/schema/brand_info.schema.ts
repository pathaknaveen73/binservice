import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, ObjectId } from 'mongoose';

export type BrandDataDocument = HydratedDocument<BrandData>;

@Schema({ collection: 'brand_config' ,autoCreate: false})
export class BrandData {
  @Prop() 
  brand_name: String;
  
}

export const BrandDataSchema = SchemaFactory.createForClass(BrandData);
