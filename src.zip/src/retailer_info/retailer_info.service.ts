import { Inject, Injectable, NotFoundException } from '@nestjs/common';
import { IRetailerInfo } from './interface/retailer_info.interface';
import { ICountryInfo } from './interface/country_info.interface';
import { IBrandInfo } from './interface/brand_info.interface';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { I18nService } from 'nestjs-i18n';
import static_data from 'src/constants/static_data';

@Injectable()
export class RetailerInfoService {
  constructor(
    @InjectModel('RetailerInfo', 'cwScrapingDB')
    private retailerInfoModel: Model<IRetailerInfo>,
    @InjectModel('CountryInfo', 'cwScrapingDB')
    private countryInfoModel: Model<ICountryInfo>,
    @InjectModel('BrandInfo', 'cwScrapingDB')
    private brandInfoModel: Model<IBrandInfo>,
    private readonly datamodel: I18nService
  ) { }
  
 /*
  * @created  : April 6, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The purpose of this function is to retrieve and manage retailer information based on the provided parameters
  * @params   : product_sku, brand_name, brand_keyword, langCode 
  * @return   : Response
  */

  async getRetailerInfo(product_sku: string, brand_name: string, brand_keyword: any, langCode: any, campaign_id:any) 
  {
     let retailerInfo = await this.getRetailerInfoDB(product_sku, brand_name, langCode);     
     if(retailerInfo.length > 0)
     {
       let globalData = await this.countryInfo("All");
       let countryData = await this.countryInfo(retailerInfo[0].country_id);
       let brandData = await this.brandInfo(retailerInfo[0].brand_id);
       retailerInfo = await this.getRetailerInfoManageDetails(retailerInfo, brand_keyword, globalData, countryData, brandData, langCode, campaign_id);
       return retailerInfo;
     }
     else
     {
       //-- Display error popup in the case provided parameters are wrong or do not exist in the DB --//
       let locData: any, hashKey='', countryName ='', brandName = '', productEAN = '', errorValue:any, errorMsg:any, errorDesc:any;
       let nestjs_server_url = process.env.NEST_SERVER_URL;
       locData = await this.locale(langCode,false);
       errorValue = static_data.INVALID_PRODUCT_SKU_CODE;
       errorMsg = locData.INVALID_PRODUCT_SKU_TXT;
       errorDesc = locData.INVALID_PRODUCT_SKU_DESC;
       retailerInfo = [{'errorCode': true, errorValue, errorMsg, errorDesc, hashKey, countryName, brandName, productEAN, nestjs_server_url}];
       const retailerObject = retailerInfo.reduce((obj, item) => {return { ...obj, ...item };}, {});
       return retailerObject;
     }
  }
  
 /*
  * @created  : April 6, 2023
  * @modified : April 7, 2023
  * @author   : Vishal Nigam
  * @access   : private
  * @Purpose  : The purpose of this function is to process and manage the retailer information obtained from the database based on the provided parameters
  * @params   : retailerInfo, brand_keyword, globalData, countryData, brandData, langCode 
  * @return   : Response
  */

  async getRetailerInfoManageDetails(retailerInfo: any, brand_keyword: any, globalData: any, countryData: any, brandData:any, langCode:any, campaign_id:any) 
  {
    let retailerDetails = [];
    let locData:any;

    //-- Localization --//
    locData = await this.locale(langCode,brandData);
    
    //-- Show Fixed Order --//
    let SFOResult = await this.checkStatus(globalData.show_fixed_order,countryData.show_fixed_order,brandData.show_fixed_order);
    if(SFOResult == '1'){ 
       //-- Sorting Retailer array by execution_prefernce-- //
       retailerInfo.sort((a: { brands_data: { execution_prefernce: number; }[]; }, b: { brands_data: { execution_prefernce: number; }[]; }) => a.brands_data[0].execution_prefernce - b.brands_data[0].execution_prefernce);
    }  
    
    for (const retDetails of retailerInfo){  
      //-- Declare variables --//
      let normalisedBrandName = '';
      let mergeurl_normalisedBrandName = '';
      let mergeurl = '';
      let mergeurl_pro = '';
      let mergeurl_final = '';
      let buyNowUrl = '';
      let campbuyNowUrl = '';
      let currencySymbol = '';
      let cw0ffer: any;
      let xpathURL = '';
      let buyNowTxt = '';
      let retailerObj:any, showpReco:any, prStatus:any, recoProducts = [];
      let brand_pdp_parameter = retDetails.brands_data[0].pdp_parameter;
      let brand_pdp_status = retDetails.brands_data[0].pdp_status;
      let brand_enable_tiny_url = retDetails.brands_data[0].enable_tiny_url;

      //-- Pdp Parmenters brand wise --//
      let pdpParameter:any;
      let pdpStatus:any;
      let enableUrl:any;

      if(brand_pdp_status == '1'){
       pdpParameter = brand_pdp_parameter;
       pdpStatus = brand_pdp_status;
      }else if(retDetails.pdp_status == '1'){
        pdpParameter = retDetails.pdp_parameter;
        pdpStatus = retDetails.pdp_status;
      }

      if(brand_enable_tiny_url == '1'){
        enableUrl = brand_enable_tiny_url;
      }else if(retDetails.enable_tiny_url == '1'){
        enableUrl = retDetails.enable_tiny_url;
      }

      let brandMarket = retDetails.brand_name;
      let productEan = retDetails.product_ean;
      let productId = retDetails.product_id;
      let productName = retDetails.retailer_product_name;
      let productURL = retDetails.retailer_product_buy_now_url;
      let productInStock = retDetails.retailer_has_product_in_stock;
      let cSymbol = retDetails.currency_symbol;
      let retailerURL = retDetails.url;
      let xPath = retDetails.xpath;
      let rProductPrice = retDetails.retailer_product_price;
      let retailerProductOffers = retDetails.retailer_product_offers;
      let isAppEnable = retDetails.is_app_enable;
      let isAppEnableTxt = locData.APP_ENABLE_TXT;
      recoProducts = retDetails.recommended_products;

      productInStock = (productInStock == true) ? productInStock :false;

      //-- Display all the retailers & their mapped Information through loop --//
      let brand = brandMarket.split('-');
      let brandName = brand[0].trim();
      //-- Fetch retailer information from retailer config --//

      //-- SET UTM Configuration --//
      if (pdpParameter) 
      {
        let mergeurlBrand = pdpParameter.replaceAll('{brand}', brandName);
        let regex = brandName.match('[@_!#$%^&*()<>?/|}{~:]') ? true : false;
        if(regex){
          normalisedBrandName = brandMarket.replaceAll('[@_!#$%^&*()<>?/|}{~:]', '-');
        }else{
          normalisedBrandName = brandMarket;
        }

        mergeurl_normalisedBrandName = mergeurlBrand.replaceAll('{normalisedBrandName}', normalisedBrandName);
        mergeurl = mergeurl_normalisedBrandName.replace('{EANNumber}', productEan);
        mergeurl_pro = mergeurl.replace('{productName}', productName);
        mergeurl_final = mergeurl_pro.replace('{PDPURL}', productURL);
      }

      if (productInStock) 
      {
        if ((pdpStatus == "1") && (pdpParameter != "")) 
        {
          if ((productURL.includes('?')) && (enableUrl != 1)) {
            if (mergeurl_final.includes('?')) {
              mergeurl_final = mergeurl_final.replace('?', '&').trim();
            }
            else {
              mergeurl_final = "&" + mergeurl_final.trim();
            }
          }
          else {
            if (mergeurl_final.includes('?')) {
                mergeurl_final = mergeurl_final.trim();
            }
          }

          if (enableUrl == 1) {
            buyNowUrl = mergeurl_final;
          }
          else {
            buyNowUrl = productURL + mergeurl_final;
          }
        }
        else {
          buyNowUrl = productURL;
        }
      }
      else
      {
        if(isAppEnable)
        {
          buyNowUrl = retailerURL;
        }
        else
        {
          if((typeof xPath != 'undefined') && (xPath != null))
          {
            const xpath_json = JSON.parse(xPath);
            if (typeof xpath_json === 'object' && xpath_json !== null) 
            {
              for (const [key, value] of Object.entries(xpath_json))
              {
                if(value)
                {
                  if(value['brand_name'] === brandMarket) 
                  {
                    if (value['listing_page_url'])
                    {
                        if (value['listing_page_url'].includes('(new_url)')) 
                        {
                          const listingUrlArr = value['listing_page_url'].split('(new_url)');
                          xpathURL = listingUrlArr[0];
                        } 
                        else if (value['listing_page_url'].includes('[brandkey]')) 
                        {
                          const listUrl = value['listing_page_url'].replace('[brandkey]', brand_keyword);
                          xpathURL = listUrl;
                        } 
                        else
                        {
                          xpathURL = value['listing_page_url'];
                        }
                      }
                  }
                }
              }
            }
          }
          
          if(enableUrl == 1)
          {
            let outurl_final = mergeurl_pro.replace('{PDPURL}', xpathURL);
            buyNowUrl = outurl_final;
          }
          else
          {
            if((mergeurl_pro) && (pdpStatus == "1"))
            {
              if ((xpathURL.includes('?')) && (mergeurl_pro.includes('?'))) {
                mergeurl_pro = mergeurl_pro.replace('?', '&').trim();
              }else {
                mergeurl_pro = mergeurl_pro.trim();
              }
              buyNowUrl = xpathURL+mergeurl_pro;
            }
            else
            {
              buyNowUrl = xpathURL; 
            }
          } 
        }
      }
      
      //-- Campaign URL --//
      if(productURL){
        campbuyNowUrl = productURL;
      }else{
         if(isAppEnable){ 
           campbuyNowUrl = retailerURL;
         }else{
           campbuyNowUrl = xpathURL;
         }
      }

      let priceResult = await this.checkStatus(globalData.show_price,countryData.show_price,brandData.show_price);
      //-- End Here --//

      //-- Retailer Offers --//
      let offerResult = await this.checkStatus(globalData.show_offer,countryData.show_offer,brandData.show_offer);
      if(offerResult == '1')
       {
         if((productInStock) && (retailerProductOffers))
         { 
            cw0ffer = retailerProductOffers.trim();
         }
         else
         {
            if(isAppEnable)
            {
              cw0ffer = isAppEnableTxt;
            }
         }
       }

       //--Retailer Product Price --//
        let priceNum: any;
        let retailer_product_price:any;
        let priceRetailerFormat:any;
        let pricePeriodFormat:any;
		    if((rProductPrice!='') && (rProductPrice!='0' || rProductPrice!='0.00'))
		    {
          if(productInStock)
		      { 
            priceNum = await this.priceInfo(rProductPrice,'','');
	        }
		    }
        
        //-- Enable Decimal Check --//
        let decimalResult = await this.checkStatus(globalData.enable_decimal_value,countryData.enable_decimal_value,brandData.enable_decimal_value);
        if(decimalResult == '1')
        {
          if(typeof priceNum != 'undefined'){
 		         retailer_product_price = await this.validateTwoDecimals(priceNum);
           }else{
             retailer_product_price = '';
           }
 		    }
        else
        {
 		    	retailer_product_price = priceNum;
 		    }
       
        if(priceResult == '1')
        {
          if((retailer_product_price!='0') && (retailer_product_price!=''))
    		  {
            if(productInStock)
		         {
               if(rProductPrice.includes(" ") && rProductPrice.includes(".") && (rProductPrice.match(/\./g)).length > 1){
                 priceRetailerFormat = await this.priceInfo(rProductPrice,'','');
               }else{
                 priceRetailerFormat = await this.priceInfo(rProductPrice,'','rFormat');
               }
    		       pricePeriodFormat = retailer_product_price;
               currencySymbol = cSymbol;
    		     }
    		  }
          else
          {
            priceRetailerFormat = '';
            pricePeriodFormat = '';
            currencySymbol = '';
          }
    		}
        else
        {
           if(campaign_id)
           {
             if((retailer_product_price!='0') && (retailer_product_price!=''))
             {
               if(productInStock)
               {
                 priceRetailerFormat = await this.priceInfo(rProductPrice,'','rFormat');
                 pricePeriodFormat = retailer_product_price;
                 currencySymbol = cSymbol;
               }
             } 
            else
            {
              priceRetailerFormat = '';
              pricePeriodFormat = '';
              currencySymbol = '';
            }
           }
        }

        //-- In Stock Or Out of Stock Text --//
  	    if(productInStock){
  		   //-- Buy Now Text --//
  		   if(isAppEnable){	
  		     buyNowTxt = locData.OPEN_APP_TXT;
  		   }else{
           buyNowTxt = locData.BUY_NOW_TXT;
  		   }
  		 }
  		 else
  		 {
  		   if(isAppEnable){
           buyNowTxt = locData.OPEN_APP_TXT;
  		   }else{
  		   	  //-- Unavailable Text --//
  		   	 buyNowTxt = locData.UNAVAILABLE_TXT;
  		   }
  		}

      //-- Production Recommendation Configuration --//
      showpReco = await this.checkStatus(globalData.show_recommend_product,countryData.show_recommend_product,brandData.show_recommend_product);
      prStatus = (showpReco == '1') ? true : false;

      let retailerPayload = {
        "prtpId": "nofollow",
        "currency_symbol": currencySymbol ?? "",
        "is_available": productInStock,
        "product_id": productId ?? "",
        "is_app_enable":isAppEnable,
        "cw_offer": cw0ffer ?? "",
        "buy_now_url": buyNowUrl,
        "campaign_buy_now": campbuyNowUrl,
        "multipack": retDetails.multipack ?? "",
        "country_name":retDetails.country_name,
        "country_code":retDetails.country_code,
        "retailer_id": retDetails.retailer_id,
        "retailer_name": retDetails.retailer_name,
        "retailer_logo": retDetails.retailer_logo,
        "buy_now_text": buyNowTxt,
        "retailer_has_product_in_stock": productInStock,
        "price_retailer_format": priceRetailerFormat ?? "",
        "price_period_format": pricePeriodFormat ?? ""
      }
      
      //-- Product Recommendation --// 
      let recoAvailable: any; 
      let recoPro = [];
      let maxR = 2;
      let eanLen = 13;

      if(prStatus)
      {
        if(typeof recoProducts != 'undefined')
        {
         if(recoProducts.length > 0)
         {
            recoAvailable = true;
            let i = 0; 
            let recoEan = [];
            for (const recommValue of recoProducts) 
            {
              if(recommValue.retailer_name == retDetails.retailer_name)
              {
                if(i < maxR)
                {
                  let retailerPrice = await this.priceInfo(recommValue.retailer_product_price, '','');
                  let recoPrice = parseFloat(retailerPrice);
                  if ((recommValue.retailer_product_name != null) && ((recoPrice != null) && (recoPrice > 0)) && (recommValue.retailer_product_buy_now_url != null))
                  { 
                    //-- Check Unique Product EAN --//
                    if(!recoEan.includes(recommValue.product_ean)) //&& (recommValue.retailer_has_product_in_stock))
                    { 
                      recoEan.push(recommValue.product_ean);
                      if(recommValue.product_ean.length == eanLen)
                      {
                        recoEan.push('0'+recommValue.product_ean);
                      }

                      //-- Make Array to Object --//
                      recoPro.push({});
                      recoPro[i]['retailer_product_name'] = recommValue.retailer_product_name;
                      recoPro[i]['retailer_product_price'] = await this.priceInfo(recommValue.retailer_product_price, cSymbol,'');
                      recoPro[i]['retailer_product_buy_now_url'] = recommValue.retailer_product_buy_now_url;
                      recoPro[i]['retailer_product_buy_txt'] = locData.BUY_NOW_TXT;
                      recoPro[i]['retailer_product_image_url'] = recommValue.retailer_product_image_url;
                      i++;
                    }
                  }
                }
              }
            }
          }
        }
      }
      
      let precoPayload = {
        "reco_available": recoAvailable,
        "alternative_product_count_txt":recoPro.length+' '+locData.ALTERNATIVE_PRODUCT_COUNT_TXT,
        "recommended_products" : recoPro
      }
       
      if((prStatus) && (recoPro.length > 0)){
        retailerObj = Object.assign(retailerPayload, precoPayload);
      }else{
        retailerObj = retailerPayload;
      }

      retailerDetails.push(retailerObj);
    }

    //-- Sorting Retailer Array by price_period_format --//
    if(SFOResult == '0'){ 
      retailerDetails.sort((a: { price_period_format: any; } , b: { price_period_format: any; }) => Number(a.price_period_format) - Number(b.price_period_format));
    }
    return retailerDetails;
  }

  async checkStatus(globalVal: any, countryVal: any, brandVal: any) {
    let getFData = '';
    if(brandVal !== ''){
      getFData = brandVal;
    }else if(countryVal !== ''){
      getFData = countryVal;
    }else{
      getFData = globalVal; 
    }
    return getFData;
  }
  
  async countryInfo(value: any)
  {
    let gcData:any;
    if(typeof value !=='string'){
      gcData = await this.countryInfoModel.aggregate([{ $match: {'_id': value}},{$project: {name:1, country_code:1, show_description: 1, show_offer:1, show_price: 1, show_recommend_product:1, enable_decimal_value:1, img_align:1, msg_text:1, price_column: 1, offer_column:1, price_symbol_position:1, show_fixed_order: 1, show_store_locator: 1, store_count: 1, search_radius:1, show_available_retailers:1, show_lowest_price:1}}]).exec();
    }else{
      gcData = await this.countryInfoModel.aggregate([{ $match: {'name': value}},{$project: {show_description: 1, show_offer:1, show_price: 1, show_recommend_product:1, enable_decimal_value:1, img_align:1, msg_text:1, price_column: 1, offer_column:1, price_symbol_position:1, show_fixed_order: 1, show_store_locator: 1, store_count: 1, search_radius:1, show_available_retailers:1, show_lowest_price:1}}]).exec();
    }

    return gcData[0];
  }

  async brandInfo(value: any)
  {
    let bData:any;
    if(typeof value !=='string'){
      bData = await this.brandInfoModel.aggregate([{ $match: {'_id': value}},{$project: {country_based:1, country_list:1, country_text:1, show_description: 1, show_offer:1, show_price: 1, show_recommend_product:1, display_msg:1, enable_decimal_value:1, img_align:1, msg_text:1, price_column: 1, offer_column:1, price_symbol_position:1, show_fixed_order: 1, show_store_locator: 1, store_count: 1, search_radius:1, show_available_retailers:1, contact_url:1, brand_name:1, enable_child_locale:1}}]).exec();
    }else{
      if((/^(?=.*\d)(?!.*-)(?=.*[a-zA-Z]).{8,}$/.test(value))){
        bData = await this.brandInfoModel.aggregate([{$unwind : "$products"},{$match : {"products.sku" : value}},{$project : {image_url : "$products.image_url"}}]).exec();    
      }else{
        bData = await this.brandInfoModel.aggregate([{ $match: {'brand_name': value}},{$project: {country_based:1, country_list:1, country_text:1, show_description: 1, show_offer:1, show_price: 1, show_recommend_product:1, display_msg:1, enable_decimal_value:1, img_align:1, msg_text:1, price_column: 1, offer_column:1, price_symbol_position:1, show_fixed_order: 1, show_store_locator: 1, store_count: 1, search_radius:1, show_available_retailers:1, contact_url:1,ga_id:1,report_suite_id:1, brand_name:1, enable_child_locale:1, show_lowest_price:1}}]).exec();
      }
    }
    return bData[0];
  }

  async priceInfo(rPrice:any,counCur:any,rFormat:any)
  { 
    let finalPrice = String(rPrice);
    let priceData = finalPrice.replace(/[^0-9,.]+/g, '').trim();
    let priceNum = await this.getValidPrice(priceData);
    if(counCur){
      return counCur+" "+priceNum;  
    }else if(rFormat){
      if(!priceData.includes(",")){
        if (!(/^[0-9]+\.[0-9]{3}$/.test(priceData))) {
           priceData = await this.validateTwoDecimals(priceData);
        }
      } 
      return priceData;
    }else{
      return priceNum;
    }
  }

  async imageInfo(imagePath:any)
  {
    let imageURL:any;
    if (imagePath != ''){
      imageURL = imagePath.replace("live", "widget");
    } else {
      imageURL = imagePath;
    }
    return imageURL;
  }

  async getValidPrice(retPrice:any) {
    let priceNum = "";
    retPrice = retPrice.trim(".", "");
    if (retPrice.includes(",")) {
      const parts = retPrice.split(",");
      if((parts.length > 0) && (parts[0].includes("."))){
        if (parts[0].includes(".")) {
          const price = parts[0].replace(".", "");
          priceNum = `${price}.${parts[1]}`;
        } 
      }
      else if ((parts.length > 0) && (!parts[0].includes("."))) 
      {
        if (parts[0].includes(".")) {
          const price = parts[0].replace(".", "");
          priceNum = `${price}.${parts[1]}`;
        } else {
          if (retPrice.includes(",")) {
            if ((parts[0].length == 1) && (parts[1].length > 2) && (parts.length == 2)) {
              priceNum = retPrice.replace(",", "");
            }else if ((parts[0].length > 2) && (parts[1].length > 2) && (parts.length == 2)) {
              priceNum = retPrice.replace(",", ".");
            } else if (parts[0].length == 1 && parts[1].length > 2 && parts.length > 2) {
              priceNum = `${parts[0]}${parts[1]}.${parts[2]}`;
            } else {
              priceNum = retPrice.replace(",", ".");
            }
          } else {
            priceNum = `${parts[0]}${parts[1]}`;
          }
        }
      }
    } 
    else if (retPrice.includes(".")){
      const parts = retPrice.split(".");
      if ((parts.length > 0) && (!parts[0].includes("."))) 
      {
        if ((parts[0].length == 1) && (parts[1].length > 2) && (parts.length == 2)) {
          priceNum = retPrice;
        } else if ((parts[0].length == 1) && (parts[1].length > 2) && (parts.length > 2)) {
          priceNum = `${parts[0]}${parts[1]}.${parts[2]}`;
        } else {
          let inComma = parts.includes("");
          if(inComma){ 
            let fparts = parts.filter((element: string) => element !== '');
            priceNum = `${fparts[0]}.${fparts[1]}`;
          }else{ 
            priceNum = retPrice;
          }
        }
      }
    } else {
      priceNum = retPrice;
    }
    return priceNum;
  }
   
  async validateTwoDecimals(number: string) {
    if (/^[0-9]+\.[0-9]{2}$/.test(number)) {
      return number;
    } else {
      return Number.parseFloat(number).toFixed(2);
    }
  }

   //-- Check Localization Globally --//
   async locale(langCode:any,brandData:any){
   let locData:any;
   if(brandData!=null && brandData.enable_child_locale){
      locData = this.datamodel.t(`locale`, { lang: `${brandData.brand_name}` || 'en'});
   }else if((langCode) && (langCode.includes("-"))){
      let localeLang = langCode.split("-");
      locData = this.datamodel.t(`locale`, { lang: `${localeLang[0]}` || 'en'});
   }else{
      locData = this.datamodel.t(`locale`, { lang: `${langCode}` || 'en'});
   }
   return locData;
  }

  async lowestPriceData(product_sku:any, brand_name: any)
  {  
    let RawInfo = await this.retailerInfoModel.aggregate([
      {
        $lookup: {
              from:'retailer_config',
              localField: 'retailer_id',
              foreignField:'_id',
              as:'retailerdata'
        }
      },
      {
        $lookup: {
              from:'country_config',
              localField:'retailerdata.country_id',
              foreignField:'_id',
              as:'countrydata'
      }
      },
      {
        $sort: {'retailer_product_price': 1}
      },
      {
        $match : {$and : 
                  [{'retailer_product_price' : {'$nin': [null,'','0.00',0,0.00]}},
                  {'retailer_has_product_in_stock' : true},
                  {'product_sku' : product_sku},
                  {'retailerdata.brands.brand_name': brand_name},
                  {'retailerdata.brands.is_relationship_active': true},
                  {'retailerdata.is_active': true}]}},
      {
        $project:{
                'retailer_product_price':1,
                'countrydata.show_price':1,
                'retailerdata.currency_symbol':1,
                'retailer_has_product_in_stock':1
        }
      }
    ]).exec();
    return RawInfo;
  }
  
  async getRetailerInfoDB(product_sku: string, brand_name: string, langCode:any) {
   const existingRetailerInfo = await this.retailerInfoModel
      .aggregate([
        {
          $lookup: {
            from: 'retailer_config',
            localField: 'retailer_id',
            foreignField: '_id',
            as: 'retailerdata',
          },
        },
        {
          $lookup: {
            from: 'country_config',
            localField: 'retailerdata.country_id',
            foreignField: '_id',
            as: 'countrydata',
          },
        },
        {
          $match: {
            $and: [{ product_sku: product_sku },
            { "retailerdata.brands.brand_name": brand_name },
            { "retailerdata.brands.is_relationship_active": true },
            { "retailerdata.is_active": true }]
          },
        },
        {
          $unwind: "$retailerdata"
        },
        {
          $project: {
            retailer_product_name: 1,
            retailer_product_buy_now_url: 1,
            retailer_has_product_in_stock: 1,
            retailer_product_offers: 1,
            retailer_product_price: 1,
            retailer_id: 1,
            retailer_name: 1,
            retailer_logo: 1,
            brand_id: 1,
            country_id:1,
            brand_name: 1,
            product_ean: 1,
            product_id: 1,
            currency_symbol: "$retailerdata.currency_symbol",
            xpath:"$retailerdata.xpath",
            is_app_enable: "$retailerdata.is_app_enable",
            url: "$retailerdata.url",
            country_name: { "$arrayElemAt": ["$countrydata.name", 0] },
            country_code: { "$arrayElemAt": ["$countrydata.country_code", 0] },
            pdp_parameter: "$retailerdata.pdp_parameter",
            pdp_status: "$retailerdata.pdp_status",
            enable_tiny_url: "$retailerdata.enable_tiny_url",
            retailer_product_sku: 1,
            multipack: 1,
            recommended_products: 1,
            brands_data: {
              $filter: {
                input: "$retailerdata.brands",
                as: "brands",
                cond: {
                    $eq: ["$$brands.brand_name",brand_name],
                  }
              }
            },
          },
        },
      ])
      .exec();
      return existingRetailerInfo;
  }


  // widget data for lowest price

  async countyBasedRowData(product_sku:any, brand_name: any){
    
    let RawInfo = await this.retailerInfoModel.aggregate([
      {
        $lookup: {
              from:'retailer_config',
              localField: 'retailer_id',
              foreignField:'_id',
              as:'retailerdata'
        }
      },
      {
        $lookup: {
              from:'country_config',
              localField:'retailerdata.country_id',
              foreignField:'_id',
              as:'countrydata'
      }
      },
      {
        $sort: {'retailer_product_price': 1}
      },
      {
        $match : {$and : 
                  [{'retailer_product_price' : {'$nin': [null,'','0.00']}},
                  {'retailer_has_product_in_stock' : true},
                  {'product_sku' : product_sku},
                  {'retailerdata.brands.brand_name': brand_name},
                  {'retailerdata.brands.is_relationship_active': true},
                  {'retailerdata.is_active': true}]}},
      {
        $project:{
                'retailer_product_price':1,
                'countrydata.show_price':1,
                'retailerdata.currency_symbol':1,
                'retailer_has_product_in_stock':1
        }
      }
    ]).exec();
    return RawInfo;
  }
}
function getLowestPrice(keyVal: any, any: any, langCode: any, any1: any) {
  throw new Error('Function not implemented.');
}

