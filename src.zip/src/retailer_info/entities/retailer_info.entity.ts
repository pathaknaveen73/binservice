export class RetailerInfo {}
