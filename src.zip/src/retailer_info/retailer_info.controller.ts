import { Controller, Get, Param } from '@nestjs/common';
import { RetailerInfoService } from './retailer_info.service';
import { ApiExcludeEndpoint } from '@nestjs/swagger';

@Controller('retailer-info')

export class RetailerInfoController {
  constructor(private readonly retailerInfoService: RetailerInfoService) {}

  //-- The purpose of the findOne function to represents a GET endpoint with multiple route parameters --//
  @Get(':product_sku/:brand_name/:langCode/:brand_keyword?/:campaign_id?')
  @ApiExcludeEndpoint()
  findOne(@Param('product_sku') product_sku: string, @Param('brand_name') brand_name: string, @Param('brand_keyword') brand_keyword: string, @Param('langCode') langCode: string, @Param('campaign_id') campaign_id: string) {
    return this.retailerInfoService.getRetailerInfo(product_sku, brand_name, brand_keyword, langCode, campaign_id);
  }
}
