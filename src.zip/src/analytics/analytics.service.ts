import { Injectable, BadRequestException,HttpException,HttpStatus} from '@nestjs/common';
import { IEngagementAnalytics } from './interface/engagement_analytics.interface';
import { IConversionAnalytics } from './interface/conversion_analytics.interface';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import ip_array from 'src/constants/ip_array';

@Injectable()
export class AnalyticsService {
  constructor(
    @InjectModel('EngagementAnalytics', 'analyticsDB')
    private engagementModel: Model<IEngagementAnalytics>,
    @InjectModel('ConversionAnalytics', 'analyticsDB')
    private conversionModel: Model<IConversionAnalytics>,
  ) { }

 /*
	* @created : Mar 21, 2023
	* @author  : Vishal Nigam
	* @access  : private
	* @Purpose : This function is used to store engagement data in the mongoDb database based on the provided post object.
	* @params  : post
	* @return  : Respnse
	*/
  async storeEngagementData(post:any,req:any)
  {
    let IpArray = ip_array;
    if(post.product_gtin!=null)
    {
      try{
        let buy_mode = "";
          if(post.buy_mode==0){
            buy_mode= 'Bin Inline'
          }
          else if(post.buy_mode==1){
            buy_mode= 'Store Locator Inline';
          }
        
          let data = {
            "product_name":post.product_name,
            'product_gtin':post.product_gtin,
            'page_url':post.page_url,
            'smart_product_id':post.smart_product_id,
            'brand_name':post.brand_name,
            'brand_code':post.brand_code,
            'country':post.country,
            'language':post.language,
            'locale':post.locale,
            'responsive_view':post.responsive_view,
            'analytics_source':post.analytics_source,
            'event_action':post.event_action,
            'report_status':post.report_status,
            'buy_mode':buy_mode,
            'area_name_search':post.area_name_search,
            'campaignId':post.campaignId,
            'campaignTitle':post.campaignTitle
          }
          if(!IpArray.includes(await this.retrieveUserIP(req))){
            const created = await this.engagementModel.create(data);
            return {status: HttpStatus.OK, "message":"Data Inserted Sucessfully"};
          }
          return {status: HttpStatus.OK, "message":"Unable to Save Data"};
        }
        catch(error){
          return new HttpException('Missing Data or Datatype Validation error', HttpStatus.BAD_REQUEST);
        }
    }
    else{
          throw new BadRequestException(`Bad Request`);
    }
  }

 /*
	* @created : Mar 21, 2023
	* @author  : Vishal Nigam
	* @access  : private
	* @Purpose : This function is used to store conversion data in the mongoDb database based on the provided post object.
	* @params  : post
	* @return  : Respnse
	*/
   
   async storeConversionData(post:any,req:any)
   {   
    let IpArray = ip_array;
     if(post.product_gtin!=null)
     {
      try{
          let data = {
            'retailer_name':post.retailer_name,
            'retailer_url':post.retailer_url,
            'product_name':post.product_name,
            'product_gtin':post.product_gtin,
            'page_url':post.page_url,
            'smart_product_id':post.smart_product_id,
            'brand_name':post.brand_name,
            'brand_code':post.brand_code,
            'price_symbol':post.price_symbol,
            'price':post.price,
            'country':post.country,
            'language':post.language,
            'locale':post.locale,
            'responsive_view':post.responsive_view,
            'analytics_source':post.analytics_source,
            'event_action':post.event_action,
            'campaignId':post.campaignId,
            'campaignTitle':post.campaignTitle
          }
          
          if(!IpArray.includes(await this.retrieveUserIP(req))){
            const created = await this.conversionModel.create(data);
            return {status: HttpStatus.OK, "messgae":"Data Inserted Sucessfully"};
          }
          return {status: HttpStatus.OK, "messgae":"Unable to Save Data"};
        }
        catch(error){
          return new HttpException('Missing Data or Datatype Validation error', HttpStatus.BAD_REQUEST);
        }
    }
    else{
          throw new BadRequestException(`Bad Request`);
    }
  }

  async retrieveUserIP(req: any) 
  {
    let address = '';
    if (req.headers['x-forwarded-for']){
      address = req.headers['x-forwarded-for'].split(',')[0];
    } else if (req.headers['client-ip']) {
      address = req.headers['client-ip'].split(',')[0];
    } else {
      address = req.connection.remoteAddress;
    }
    return address.trim();
  }

}

