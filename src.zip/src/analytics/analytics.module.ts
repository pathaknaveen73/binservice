import { AnalyticsService } from './analytics.service';
import { EngagementDataSchema } from './schema/engagement_analytics.schema';
import { ConversionDataSchema } from './schema/conversion_analytics.schema';
import { AnalyticsController } from './analytics.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { ConfigModule } from '@nestjs/config';
import { CacheModule, Module, CacheInterceptor  } from '@nestjs/common';

@Module({
  imports: [
   /* CacheModule.register({
      isGlobal: true,
      ttl: 300000, // mili seconds
    }), */
    //process.env.DB_CONNECT_CW_ANALYTICS
    ConfigModule.forRoot(),
    MongooseModule.forRoot(process.env.DB_CONNECT_CW_ANALYTICS, {connectionName: 'analyticsDB'}),
    MongooseModule.forFeature([
      { name: 'EngagementAnalytics', schema: EngagementDataSchema },
      { name: 'ConversionAnalytics', schema: ConversionDataSchema }
    ], 'analyticsDB'),

  ],
  controllers: [AnalyticsController],
  providers: [AnalyticsService],
  exports: [AnalyticsService]
})
export class AnalyticsModule {}
