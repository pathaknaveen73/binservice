import { Document } from 'mongoose';
export interface IEngagementAnalytics extends Document {
    readonly product_name: String;
    readonly product_gtin: String;
    readonly page_url: String;
    readonly smart_product_id: String;
    readonly brand_name: String;
    readonly brand_code: String;
    readonly country: String;
    readonly language: String;
    readonly locale: String;
    readonly responsive_view: String;
    readonly analytics_source: String;
    readonly event_action: String;
    readonly report_status: String;
    readonly buy_mode: String;
    readonly area_name_search: String;
    readonly campaignId: String;
    readonly campaignTitle: String;
}