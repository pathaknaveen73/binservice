import { Document } from 'mongoose';
export interface IConversionAnalytics extends Document {
    readonly retailer_name: String;
    readonly retailer_url: String;
    readonly product_name: String;
    readonly product_gtin: String;
    readonly page_url: String;
    readonly smart_product_id: String;
    readonly brand_name: String;
    readonly brand_code: String;
    readonly price_symbol: String;
    readonly price: Number;
    readonly country: String;
    readonly language: String;
    readonly locale: String;
    readonly responsive_view: String;
    readonly analytics_source: String;
    readonly event_action: String;
    readonly campaignId: String;
    readonly campaignTitle: String;
}