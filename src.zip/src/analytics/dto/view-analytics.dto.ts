import { ApiProperty } from '@nestjs/swagger';
export class viewAnalyticsDto {

  @ApiProperty()
  product_name: String;

  @ApiProperty()
  product_gtin: String;
  
  @ApiProperty()
  page_url: String;

  @ApiProperty() 
  smart_product_id: String;
  
  @ApiProperty()
  brand_name: String;
  
  @ApiProperty()
  brand_code: String;
  
  @ApiProperty()
  country: String;
  
  @ApiProperty()
  language: String;
  
  @ApiProperty()
  locale: String;
  
  @ApiProperty()
  responsive_view: String;
  
  @ApiProperty()
  analytics_source: String;

  @ApiProperty()
  event_action: String;
  
  @ApiProperty()
  report_status: String;

  @ApiProperty()
  buy_mode: String;
  
  @ApiProperty()
  area_name_search: String;

  @ApiProperty()
  campaignId: String;

  @ApiProperty()
  campaignTitle: String;
}
