import { ApiProperty } from '@nestjs/swagger';
export class clickAnalyticsDto {
    @ApiProperty()
    retailer_name: String;
  
    @ApiProperty()
    retailer_url: String;
  
    @ApiProperty()
    product_name: String;
  
    @ApiProperty() 
    product_gtin: String;
    
    @ApiProperty()
    page_url: String;
  
    @ApiProperty() 
    smart_product_id: String;
    
    @ApiProperty()
    brand_name: String;
    
    @ApiProperty()
    brand_code: String;
    
    @ApiProperty()
    price_symbol: String;
  
    @ApiProperty()
    price: Number;
  
    @ApiProperty()
    country: String;
    
    @ApiProperty()
    language: String;
    
    @ApiProperty()
    locale: String;
    
    @ApiProperty()
    responsive_view: String;
    
    @ApiProperty() 
    analytics_source: String;
  
    @ApiProperty()
    event_action: String;
  
    @ApiProperty()
    campaignId: String;
  
    @ApiProperty()
    campaignTitle: String;
}
