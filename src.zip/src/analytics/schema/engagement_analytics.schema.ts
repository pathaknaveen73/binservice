import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, ObjectId } from 'mongoose';

export type EngagementDataDocument = HydratedDocument<EngagementData>;

@Schema({ collection: 'engagement_analytics',autoCreate: false, versionKey: false, timestamps: {createdAt: 'created_date',updatedAt: false}})
export class EngagementData {

  @Prop() 
  product_name: String;

  @Prop() 
  product_gtin: String;
  
  @Prop()
  page_url: String;

  @Prop() 
  smart_product_id: String;
  
  @Prop() 
  brand_name: String;
  
  @Prop() 
  brand_code: String;
  
  @Prop() 
  country: String;
  
  @Prop() 
  language: String;
  
  @Prop() 
  locale: String;
  
  @Prop() 
  responsive_view: String;
  
  @Prop() 
  analytics_source: String;

  @Prop() 
  event_action: String;
  
  @Prop()
  report_status: String;

  @Prop()
  buy_mode: String;
  
  @Prop() 
  area_name_search: String;

  @Prop() 
  campaignId: String;

  @Prop()
  campaignTitle: String;

}

export const EngagementDataSchema = SchemaFactory.createForClass(EngagementData);