import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument, ObjectId } from 'mongoose';

export type ConversionDataDocument = HydratedDocument<ConversionData>;

@Schema({ collection: 'conversion_analytics',autoCreate: false, versionKey: false, timestamps: {createdAt: 'created_date',updatedAt: false}})
export class ConversionData {

  @Prop()
  retailer_name: String;

  @Prop()
  retailer_url: String;

  @Prop() 
  product_name: String;

  @Prop() 
  product_gtin: String;
  
  @Prop()
  page_url: String;

  @Prop() 
  smart_product_id: String;
  
  @Prop() 
  brand_name: String;
  
  @Prop() 
  brand_code: String;
  
  @Prop()
  price_symbol: String;

  @Prop()
  price: Number;

  @Prop() 
  country: String;
  
  @Prop() 
  language: String;
  
  @Prop() 
  locale: String;
  
  @Prop() 
  responsive_view: String;
  
  @Prop() 
  analytics_source: String;

  @Prop() 
  event_action: String;

  @Prop() 
  campaignId: String;

  @Prop()
  campaignTitle: String;

}

export const ConversionDataSchema = SchemaFactory.createForClass(ConversionData);