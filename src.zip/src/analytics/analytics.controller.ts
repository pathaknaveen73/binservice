import { Controller, Post, Body, Req } from '@nestjs/common';
import { AnalyticsService } from './analytics.service';
import { clickAnalyticsDto } from './dto/click-analytics.dto';
import { viewAnalyticsDto } from './dto/view-analytics.dto';
import { Request } from 'express';

@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

//-- The purpose of the cwanalyticsview function is to handle a POST request to the cwanalyticsview endpoint --//
  @Post('cwanalyticsview')
    cwanalyticsview(@Body() viewAnalyticsDto: viewAnalyticsDto, @Req() request: Request) {
    return this.analyticsService.storeEngagementData(viewAnalyticsDto,request);
  }

//-- The purpose of the cwanalyticsclick function is to handle a POST request to the cwanalyticsclick endpoint --//
  @Post('cwanalyticsclick')
  cwanalyticsclick(@Body() clickAnalyticsDto: clickAnalyticsDto, @Req() request: Request) {
    return this.analyticsService.storeConversionData(clickAnalyticsDto,request);
  }
}
