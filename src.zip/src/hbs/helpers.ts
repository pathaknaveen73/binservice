export function printName(name) {
  const output = `<div> ${name}</div>`;
  return output;
}
export function recLength (obj){
  if(obj && Object.keys(obj).length >1){
    return true;
  }
  else{
    return false;
  }
}
export function splitHead(name,index) {
    try{
      const output = name.split(",");
  
      return output[index];
    }
    catch(e){ return "";}

}
export function  singleLineOnly(options) { // "this" cannot be provided to inline function!
  try{
    return options.replace('&quot;\r\n', '');
  }catch(e){return "";}
  //  return options.replace('&quot;\r\n', '');
  }
export function getLink(text,url,stock_txt) {
  
  const output = text.replace("##", "").replace("[/a]", "</a>").replace("[a]", "<a class=\"view_products cwObj\" target='_blank' href='" + url + "'>");
  return stock_txt +", "+ output + "<a href='"+url+"' target='_blank' class='ooslink'><svg width=\"16\" height=\"16\" viewBox=\"0 0 16 16\" fill=\"none\"            xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M12.0007 7.21331C11.8238 7.21331 11.6543 7.28355 11.5292 7.40857C11.4042 7.5336 11.334 7.70317 11.334 7.87998V12.6666C11.334 12.8435 11.2637 13.013 11.1387 13.1381C11.0137 13.2631 10.8441 13.3333 10.6673 13.3333H3.33398C3.15717 13.3333 2.9876 13.2631 2.86258 13.1381C2.73756 13.013 2.66732 12.8435 2.66732 12.6666V5.33331C2.66732 5.1565 2.73756 4.98693 2.86258 4.86191C2.9876 4.73688 3.15717 4.66665 3.33398 4.66665H8.12065C8.29746 4.66665 8.46703 4.59641 8.59206 4.47138C8.71708 4.34636 8.78732 4.17679 8.78732 3.99998C8.78732 3.82317 8.71708 3.6536 8.59206 3.52858C8.46703 3.40355 8.29746 3.33331 8.12065 3.33331H3.33398C2.80355 3.33331 2.29484 3.54403 1.91977 3.9191C1.5447 4.29417 1.33398 4.80288 1.33398 5.33331V12.6666C1.33398 13.1971 1.5447 13.7058 1.91977 14.0809C2.29484 14.4559 2.80355 14.6666 3.33398 14.6666H10.6673C11.1978 14.6666 11.7065 14.4559 12.0815 14.0809C12.4566 13.7058 12.6673 13.1971 12.6673 12.6666V7.87998C12.6673 7.70317 12.5971 7.5336 12.4721 7.40857C12.347 7.28355 12.1775 7.21331 12.0007 7.21331ZM14.614 1.74665C14.5463 1.58375 14.4169 1.4543 14.254 1.38665C14.1738 1.35249 14.0878 1.33437 14.0007 1.33331H10.0007C9.82384 1.33331 9.65427 1.40355 9.52925 1.52858C9.40422 1.6536 9.33398 1.82317 9.33398 1.99998C9.33398 2.17679 9.40422 2.34636 9.52925 2.47138C9.65427 2.59641 9.82384 2.66665 10.0007 2.66665H12.394L5.52732 9.52665C5.46483 9.58862 5.41524 9.66236 5.38139 9.74359C5.34754 9.82483 5.33012 9.91197 5.33012 9.99998C5.33012 10.088 5.34754 10.1751 5.38139 10.2564C5.41524 10.3376 5.46483 10.4113 5.52732 10.4733C5.58929 10.5358 5.66303 10.5854 5.74427 10.6192C5.82551 10.6531 5.91264 10.6705 6.00065 10.6705C6.08866 10.6705 6.1758 10.6531 6.25704 10.6192C6.33827 10.5854 6.41201 10.5358 6.47398 10.4733L13.334 3.60665V5.99998C13.334 6.17679 13.4042 6.34636 13.5292 6.47138C13.6543 6.59641 13.8238 6.66665 14.0007 6.66665C14.1775 6.66665 14.347 6.59641 14.4721 6.47138C14.5971 6.34636 14.6673 6.17679 14.6673 5.99998V1.99998C14.6663 1.91286 14.6481 1.82679 14.614 1.74665Z\"               fill=\"black\"></path>         </svg></a>";
 // return output[index];
}
export function toggleBtn(cond,_cond,text) {
if(cond == _cond){

//return "<div class=\"cw_up_down_arrow cw_accordine\" style=\"\"> <a href=\"javascript:void(0)\"><span class=\"cw_up_arrow\"></span></a></div>";
return "";
}
else{
  return "";
}
}
export function sort(name,index) {
  try{
    const output = name.split(",");

    return output[index];
  }catch(e){
    return "";
  }

}

export function xif(expression, options) {
  return this.helpers["x"].apply(this, [expression, options]) ? options.fn(this) : options.inverse(this);
}
export function eq(c1,c2) {
if(c1==c2){
  return true;
}else{
  return false;
}

}