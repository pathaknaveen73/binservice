import { Injectable, BadRequestException, HttpStatus, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { IbinKanaApiGet } from './interface/bin_kana_api_get.interface';
import { IbinKanaApiPost } from './interface/bin_kana_api_post.interface';
import axios from 'axios';
import { URL } from 'url';
import static_data from 'src/constants/static_data';

@Injectable()
export class BinKanaApiService {
  constructor(
    @InjectModel('binKanaApiGet', 'kanaApiDB')
    private binKanaApiGetModel: Model<IbinKanaApiGet>,
    @InjectModel('binKanaApiPost', 'kanaApiDB')
    private binKanaApiPostModel: Model<IbinKanaApiPost>,
  ) { }

 /*
	* @created : April 19, 2023
	* @author  : Vishal Nigam
	* @access  : private
	* @Purpose : This function is used to Fetch the data from the API and Store the data into database.
	* @params  : none
	* @return  : Respnse
	*/

  async getBinkanaApi(){
    axios({
      method: 'get',
      url: process.env.KANA_API_URL,
      headers: {
        'authorization': process.env.KANA_API_KEY,
        'cache-control': 'no-cache'
      }
    })
      .then( async response => {
        let r = await this.binKanaApiGetModel.deleteMany({})
        for (const [datakey, data] of Object.entries(response.data)){
          for (const [valuekey, value] of Object.entries(data)){
            let data = {
              "brand_name":value.u_brand.display_value,
              "brand_url": value.name,
             "country_name":value.location.display_value,
             "plateform":value.u_platform.display_value,
            }
            let result = await this.binKanaApiGetModel.create(data);
          }
        }
      })
      .catch(error => {
        return new BadRequestException(`Unable to fetch Data from API`);
      })
  }


 /*
	* @created : April 20, 2023
	* @author  : Vishal Nigam
	* @access  : private
	* @Purpose : This function is uued to Fetch the data from the Post, API and Generate Kana ticket Store the data into database.
	* @params  : post
	* @return  : Respnse
	*/

  async postBinkanaApi(post :any)
  {
    const udhd_username = process.env.UDHD_USERNAME;
    const udhd_pwd  = String(process.env.UDHD_PWD);
    const udhd_url = process.env.UDHD_URL;
    if ((post.bin_error == '' && post.pdp_url == '') || (post.bin_error != '' && post.pdp_url == '') || (post.bin_error == '' && post.pdp_url != ''))
    {
      return new NotFoundException('Missing Required Json Parameters!');
    }
    else
    {
      if (post.bin_error === '101' || post.bin_error === '102' || post.bin_error === '103' || post.bin_error === '105') {
        const brand_name     = post.brand_name ? post.brand_name.split(' - ')[0] : '';
        const country_name   = post.country_name?post.country_name:'';
        const pdpUrl 			   = post.pdp_url;
				const SmartproductId = post.SmartProductId;
        
        let description ='';
        let short_description = '';
        let brand_url ='';

        if (post.bin_error === '101') {
          const PDP_URL = static_data.DESCRIPTION_101.replace('PDP_URL', pdpUrl);
          description = PDP_URL.replace('HASH_KEY', SmartproductId);
          short_description = static_data.SHORT_DESCRIPTION_101;
        } else if (post.bin_error === '105') {
          const PDP_URL = static_data.DESCRIPTION_105.replace('PDP_URL', pdpUrl);
          description = PDP_URL.replace('HASH_KEY', SmartproductId);
          short_description = static_data.SHORT_DESCRIPTION_105;
        } else if (post.bin_error === '102') {
          description = static_data.DESCRIPTION_102.replace('PDP_URL', pdpUrl);
          short_description = static_data.SHORT_DESCRIPTION_102;
        } else if (post.bin_error === '103') {
          description = static_data.DESCRIPTION_103.replace('PDP_URL', pdpUrl);
          short_description = static_data.SHORT_DESCRIPTION_103;
        } else {
          description = '';
        }

        //Value PDP_URL-----HASH_KEY
				const contact				= static_data.CONTACT;
				const category			= static_data.CATEGORY;
				const subcategory		= static_data.SUBCATEGORY;
				const impact				= static_data.IMPACT;
				const urgency				= static_data.URGENCY;

        //Find Error on config collection+
				if (country_name != '' && brand_name != '') {
          let regex = new RegExp(brand_name, 'i');
          let queryPrms = { $and: [{ country_name: country_name }, { brand_name: { $regex: regex } }] };
          let query = await this.binKanaApiGetModel
            .aggregate([
              { $match: queryPrms },
              {
                $project: {
                  country_name: 1,
                  brand_url: 1,
                  created_on: 1,
                  updated_on: 1,
                  brand_name: 1,
                },
              },
            ])
            .exec();
            if(query.length!=0){ 
              brand_url = query[0].brand_url;
            }
        }
        else
        {
          const parsedUrl = new URL(pdpUrl);
          const pathSplit = parsedUrl.pathname.split('/');
          const wwwChk = 'www.';
          let hostUrl = parsedUrl.hostname;

          if (hostUrl.includes(wwwChk)) {
            const tUrl = hostUrl.split('www.');
            hostUrl = tUrl[1];
          }
          else{
            hostUrl = parsedUrl.hostname;
          }
          const regex = new RegExp(hostUrl, "i");
          const queryPrms = [
            { "brand_url": { "$regex": regex } }
          ];

          const query = await this.binKanaApiGetModel.aggregate([
            { "$match": { "$and": queryPrms } },
            { "$project": { 
              "country_name": 1, 
              "brand_url": 1, 
              "created_on": 1, 
              "updated_on": 1, 
              "brand_name": 1 
            } }
          ]).exec();

          if(query.length==1){
            brand_url = query[0].brand_url;
          }
          else
          {
            hostUrl = hostUrl + '/' + pathSplit[1];
            const regex = new RegExp(hostUrl, "i");
            const queryPrms = [
              { "brand_url": { "$regex": regex } }
            ];

            const query = await this.binKanaApiGetModel.aggregate([
              { "$match": { "$and": queryPrms } },
              { "$project": { 
                "country_name": 1, 
                "brand_url": 1, 
                "created_on": 1, 
                "updated_on": 1, 
                "brand_name": 1 
              } }
            ]).exec();

            if(query.length==1){
              brand_url = query[0].brand_url;
            }
            else
            {
              hostUrl = hostUrl + '/' + pathSplit[1]+'/'+pathSplit[2];
              const regex = new RegExp(hostUrl, "i");
              const queryPrms = [
                { "brand_url": { "$regex": regex } }
                ];
              const query = await this.binKanaApiGetModel.aggregate([
                { "$match": { "$and": queryPrms } },
                { "$project": { 
                "country_name": 1, 
                "brand_url": 1, 
                "created_on": 1, 
                "updated_on": 1, 
                "brand_name": 1 
                } }
              ]).exec();

              if(query.length==1){
                brand_url = query[0].brand_url;
              }
              else
              {
                hostUrl = hostUrl + '/' + pathSplit[1]+'/'+pathSplit[2]+'/'+pathSplit[3];
                const regex = new RegExp(hostUrl, "i");
                const queryPrms = [
                  { "brand_url": { "$regex": regex } }
                  ];
                const query = await this.binKanaApiGetModel.aggregate([
                  { "$match": { "$and": queryPrms } },
                  { "$project": { 
                  "country_name": 1, 
                  "brand_url": 1, 
                  "created_on": 1, 
                  "updated_on": 1, 
                  "brand_name": 1 
                  } }
                ]).exec();
                if(query.length==1){
                  brand_url = query[0].brand_url;
                }
              }
            }
          }
        }
        //store data in json obj
        let postjson = {
          'contact':contact,
          'category':category,
          'subcategory':subcategory,
          'short_description':short_description,
          'description':description,
          'impact':impact,
          'urgency':urgency,
          'u_application_service':brand_url,
          'pdp_url':pdpUrl
        }
        if (brand_url != '') {
          const date = new Date();
          let timestamp = new Date(date.getTime());
          let getErrorLog = await this.binKanaApiPostModel.find({'brand_url': brand_url,'bin_error':post.bin_error,'is_active':true}).exec();
          if(getErrorLog.length>0){
            const id = getErrorLog[0]._id;
            const kana_ticket = getErrorLog[0].kana_ticket;
            const pdp_url = getErrorLog[0].pdp_url;
            const now = new Date().toISOString().slice(0,10);
            const created_Date = getErrorLog[0].created_on.toISOString().slice(0,10);
            const pastDate = new Date(created_Date);
            const currentDate = new Date(now);
            const no_of_days = (currentDate.getTime() - pastDate.getTime()) / (1000 * 3600 * 24);

            if (no_of_days < 90 && no_of_days >= 0) {
              const collecteddata = [{
                  kana_ticket: kana_ticket,
                  pdp_url: pdp_url,
                  contact: contact,
                  category: category,
                  subcategory: subcategory,
                  short_description: short_description,
                  description: description,
                  impact: impact,
                  urgency: urgency,
                  created_on: new Date(getErrorLog[0].created_on),
                  updated_on: new Date(timestamp),
                  is_active: true,
                  bin_error: post.bin_error,
                  brand_url: brand_url
              }];
              await this.binKanaApiPostModel.findByIdAndUpdate(id,{'$push':{logs:collecteddata}}, { new: true })
              
              .then((updatedPost) => {
              })
              .catch((err) => {

               });
              return { status: HttpStatus.OK, message: "Data is inserted" };
            }
            else
            {
              await this.binKanaApiPostModel.findByIdAndUpdate(id,{'$set':{'is_active':false}}, { new: true })
              let config ={
                auth: {
                  username: udhd_username,
                  password: udhd_pwd
                },
                headers: {
                  'authorization': process.env.KANA_API_KEY,
                  'cache-control': 'no-cache',
                  'content-type' : 'application/json'
                }
              };

              await axios.post(udhd_url, postjson, config)
                .then(async (response) => {
                  let resData = [{
                    kana_ticket: response.data.result.number,
                    pdp_url: pdp_url,
                    contact: contact,
                    category: category,
                    subcategory: subcategory,
                    short_description: short_description,
                    description: description,
                    impact: impact,
                    urgency: urgency,
                    created_on: new Date(timestamp),
                    updated_on: new Date(timestamp),
                    is_active: true,
                    bin_error: post.bin_error,
                    logs:[],
                    brand_url: brand_url
                  }];
                  
                  await this.binKanaApiPostModel.create(resData);
                })
                .catch((error) => {
                  throw new NotFoundException('Unable to Save Data');
              })
              return { status: HttpStatus.OK, message: "Data is inserted" };
            }
          }
          else
          {
            let config ={

              auth: {
                username: udhd_username,
                password: udhd_pwd
              },
              headers: {
                'authorization': process.env.KANA_API_KEY,
                'cache-control': 'no-cache',
                'content-type' : 'application/json'
              }
            };

            await axios.post(udhd_url, postjson, config)
              .then(async (response) => {
                  let resData = [{
                  kana_ticket: response.data.result.number,
                  pdp_url: pdpUrl,
                  contact: contact,
                  category: category,
                  subcategory: subcategory,
                  short_description: short_description,
                  description: description,
                  impact: impact,
                  urgency: urgency,
                  created_on: new Date(timestamp),
                  updated_on: new Date(timestamp),
                  is_active: true,
                  bin_error: post.bin_error,
                  logs:[],
                  brand_url: brand_url
                }];

                await this.binKanaApiPostModel.create(resData);
              })
              .catch((error) => {
                throw new NotFoundException('Unable to Save Data');
            })
            return {status: HttpStatus.OK, "message":"Data is Inseted"};
          } 
        }
        else
        {
          return new NotFoundException('No Record Found!');
        }
      }
      else
      {
        return new NotFoundException('This error nnumber is not found.!!!');
      }
    }
  }
}
