import { Document } from 'mongoose';

export interface IbinKanaApiGet extends Document {
  readonly brand_name: string;
  readonly brand_url: String;
  readonly country_name: String;
  readonly plateform: String;
  readonly created_date: Date;
}
