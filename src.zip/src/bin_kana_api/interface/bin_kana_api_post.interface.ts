import { Document,ObjectId } from 'mongoose';

export interface IbinKanaApiPost extends Document {
  readonly _id: ObjectId;
  readonly kana_ticket: String;
  readonly pdp_url: String;
  readonly contact: String;
  readonly category: String;
  readonly subcategory: String;
  readonly short_description: String;
  readonly description: String;
  readonly impact: String;
  readonly urgency: String;
  readonly created_on: Date;
  readonly updated_on: Date;
  readonly logs: {
    kana_ticket: string;
    pdp_url: string;
    contact: String;
    category: String;
    subcategory: String;
    short_description: String;
    impact: String;
    urgency: String;
    created_on: Date;
    updated_on: Date;
    description: string;
    is_active: Boolean
    bin_error: String;
    brand_url: String;
  }[];
  readonly is_active: Boolean;
  readonly bin_error: String;
  readonly brand_url: String;
}
