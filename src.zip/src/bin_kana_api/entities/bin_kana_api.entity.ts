export class BinKanaApi {}
