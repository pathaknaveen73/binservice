import { Test, TestingModule } from '@nestjs/testing';
import { BinKanaApiController } from './bin_kana_api.controller';
import { BinKanaApiService } from './bin_kana_api.service';

describe('BinKanaApiController', () => {
  let controller: BinKanaApiController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BinKanaApiController],
      providers: [BinKanaApiService],
    }).compile();

    controller = module.get<BinKanaApiController>(BinKanaApiController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
