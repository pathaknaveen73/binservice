import { Test, TestingModule } from '@nestjs/testing';
import { BinKanaApiService } from './bin_kana_api.service';

describe('BinKanaApiService', () => {
  let service: BinKanaApiService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [BinKanaApiService],
    }).compile();

    service = module.get<BinKanaApiService>(BinKanaApiService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
