import { Controller, Get, Post, Body } from '@nestjs/common';
import { BinKanaApiService } from './bin_kana_api.service';
import { CreateBinKanaApiDto } from './dto/create-bin_kana_api.dto';

@Controller('bin_kana_api')
export class BinKanaApiController {
  constructor(private readonly binKanaApiService: BinKanaApiService) {}

 //-- The purpose of the create function is to handle a POST request to the root endpoint --//
  @Post()
  create(@Body() createBinKanaApiDto: CreateBinKanaApiDto) {
    return this.binKanaApiService.postBinkanaApi(createBinKanaApiDto);
  }
//-- The purpose of the findAll function is to handle a GET request to the root endpoint --//
  @Get()
  findAll() {
    return this.binKanaApiService.getBinkanaApi();
  }
}
