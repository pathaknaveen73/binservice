import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { BinKanaApiService } from './bin_kana_api.service';
import { BinKanaApiController } from './bin_kana_api.controller';
import { binKanaApiGetSchema } from './schema/bin_kana_api_get.schema';
import { binKanaApiPostSchema } from './schema/bin_kana_api_post.schema';

@Module({
  imports: [
     MongooseModule.forRoot(process.env.DB_CONNECT_CW_PORTAL, {connectionName: 'kanaApiDB'}),
     MongooseModule.forFeature([
      { name: 'binKanaApiGet', schema: binKanaApiGetSchema },
      { name: 'binKanaApiPost', schema: binKanaApiPostSchema }
     ], 'kanaApiDB'),
 
   ],
  controllers: [BinKanaApiController],
  providers: [BinKanaApiService]
})
export class BinKanaApiModule {}
