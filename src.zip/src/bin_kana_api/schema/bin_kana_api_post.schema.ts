import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({ collection: 'kana_api_data', autoCreate:false, versionKey: false, timestamps: {createdAt: 'created_on',updatedAt: false}})
export class binKanaApiPost {

  @Prop()
  kana_ticket: String;

  @Prop()
  pdp_url: String;

  @Prop()
  contact: String;

  @Prop()
  category: String;

  @Prop()
  subcategory: String;

  @Prop()
  short_description: String;

  @Prop()
  description: String;

  @Prop()
  impact: String;

  @Prop()
  urgency: String;

  @Prop()
  created_on: Date;

  @Prop()
  updated_on: Date;

  @Prop([{
    kana_ticket: String, 
    pdp_url: String, 
    contact: String,
    category: String,
    subcategory: String,
    short_description: String,
    impact: String,
    urgency: String,
    created_on: Date,
    updated_on: Date,
    description: String,
    is_active: Boolean,
    bin_error: String,
    brand_url: String, }])
  logs: {
    kana_ticket: string;
    pdp_url: string;
    contact: String;
    category: String;
    subcategory: String;
    short_description: String;
    impact: String;
    urgency: String;
    created_on: Date;
    updated_on: Date;
    description: string;
    is_active: Boolean
    bin_error: String;
    brand_url: String;
  }[];

  @Prop()
  is_active: Boolean;

  @Prop()
  bin_error: String;

  @Prop()
  brand_url: String;

}

export const binKanaApiPostSchema = SchemaFactory.createForClass(binKanaApiPost);
