import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';

@Schema({ collection: 'kana_brand_config', autoCreate: false,versionKey: false, timestamps: {createdAt: 'created_on',updatedAt: false}})
export class binKanaApiGet {
  @Prop()
  brand_name: String;

  @Prop()
  brand_url: String;

  @Prop()
  country_name: String;

  @Prop()
  plateform: String;

  @Prop()
  created_on: Date;
}

export const binKanaApiGetSchema = SchemaFactory.createForClass(binKanaApiGet);
