import { ApiProperty } from '@nestjs/swagger';
export class CreateBinKanaApiDto {
    @ApiProperty()
    bin_error: String;
  
    @ApiProperty()
    brand_name: String;
  
    @ApiProperty()
    country_name: String;
  
    @ApiProperty()
    pdp_url: String;
  
    @ApiProperty()
    SmartproductId: String;

}
